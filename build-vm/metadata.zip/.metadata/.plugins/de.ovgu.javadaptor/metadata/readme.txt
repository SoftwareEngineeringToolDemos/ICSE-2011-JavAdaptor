Die Dateine in diesem Ordner werden bei der Aktivierung des Plugins in den Ordner "<workspace>/.metadata/.plugin/de.ovgu.javadaptor" kopiert.

Wenn der Ordner "de.ovgu.javadaptor" schon vorhanden ist, werden die Dateien ignoriert.
Der Unterordner "classReplacement" wird in das Runprojekt der einzelnen Applikation (<project>/bin) bei der Verwendung des Plugins kopiert.

Die Dateinen des Ordners m�ssen einzeln aktualisiert werden, vorallem wenn sich die StartApplikation �ndert.