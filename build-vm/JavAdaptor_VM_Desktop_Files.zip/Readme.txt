############################################################
#                    Javadaptor Plugin                     #
############################################################

====================================================
Instructions to Run JavAdaptor Snake Demo on this VM
====================================================

  1. Assumes that javadaptor plugin is already integrated with Eclipse (you may have to obtain the plugin from Authors).
  2. Switch to Eclipse (should be launched on startup or launch from Desktop if not open).
  3. Close the "Welcome" screen (if opened). Project Snake Demo should be already imported.
  4. Go to Run -> Run Configurations... (on the left pane of pop-up you should see JavAdaptor)
        4.1 Click the down-arrow next to JavaAdaptor and Select JavaAdaptor_Configuration.
		4.2 Click Run.
  
  5. Wait for the Snake Application to launch. A pop-up should be displayed saying "Application started".
  6. The Snake Demo should be launched and visible (a snake roaming about in a black area).
  7. Try out the 4 types of updates for Snake Demo one by one** (read next step on how to activate changes).
    For each of the updates look for the TODO (and update#) tag in the relevant files and make suggested change (comment/uncomment). Save changes.
        - update1 : Files : [src->paint->FieldPainter.java]
        - update2 : Files : [src->entitys->EntityHelpings.java, src->basics->GameField.java]
        - update3 : Files : [src->basics->GameField.java, src->entitys->Bug.java, src->paint->Painter.java]
        - update4 : Files : [src->basics->GameField.java, src->entitys->Snake.java]
  8. After making each change, upload the changes :
	- Connect JavAdaptor with the running application using the connect button (C)
	- Use the reload button (R) to update your running application
	- Disconnect JavAdaptor using the connect button (C)
        ! You can keep JavAdaptor conected as long as you need to and reload your classes multiple times without disconnecting it.

  9. JavAdaptor Plugin can be found here :- /opt/eclipse/plugins/javadaptor-0.9.5.jar

** If in doubt, refer to any one of the two tutorial videos whose links are provided on Desktop.

