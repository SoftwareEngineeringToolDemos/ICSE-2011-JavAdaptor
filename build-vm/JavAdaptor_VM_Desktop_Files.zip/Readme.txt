############################################################
#                    Javadaptor Plugin                     #
############################################################

====================================================
Instructions to Run JavAdaptor Snake Demo on this VM
====================================================

  - Assumes that javadaptor plugin is already integrated with Eclipse.
  - Switch to Eclipse (launch from Desktop if not open).
  - Project Snake Demo should be already opened.
  - Run as 1 Javadaptor_configuration (absolutely critical).
  - The Snake Demo should be launched and visible.
  - Try out the 4 types of updates for Snake Demo one by one** (read next step on how to activate changes).
    For each of the updates look for the TODO (and update#) tag in the relevant files and make suggesting change (comment/uncomment). Save changes.
        - update1 : Files : [FieldPainter.java]
        - update2 : Files : [EntityHelpings.java, GameField.java]
        - update3 : Files : [GameField.java, Bug.java, Painter.java]
        - update4 : Files : [GameField.java, Snake.java]
  - After making each change, upload the changes :
	- Connect JavAdaptor with the running application using the connect button (C)
	- Use the reload button (R) to update your running application
	- Disconnect JavAdaptor using the connect button (C)
        ! You can keep JavAdaptor conected as long as you need to and reload your classes multiple times without disconnecting it.

  - JavAdaptor Plugin can be found here :- /home/user/eclipse/plugins/javadaptor-0.9.5.jar

** If in doubt, refer to any one of the two tutorial videos whose links are provided on Desktop.

