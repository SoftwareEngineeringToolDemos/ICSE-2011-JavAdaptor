/*
 * PointsHighscore.java
 *
 * Created on 16. Februar 2008, 17:49
 *
 *  Struct der den Namen und die Punkte speichert (Highscore).
 */

package menu;

/**
 * Struktur die den Namen und die zugeh�rigen Punkte speichert.
 *
 * @author Alexander Grebhahn,
 *          Reimar Schr�ter
 */
public class PointsHighscore {
    String name="";
    int points=0;
    
    /** Creates a new instance of Highscore */
    public PointsHighscore() {
        
    }
    
    /**
     * Erstellt einen neuen Highscore-Eintrag.
     * 
     * @param name1   Name zum zugeh�rigen Punktwert
     * @param points1 Punktwert der erreicht wurde
     */
    public PointsHighscore(String name1,int points1){
        name=name1;
        points=points1;
    }
    
    /**
     *  Setzt Punktwert.
     * 
     * @param points1  Punkte die eingetragen werden sollen
     */
    public void setPoints(int points1){
        points=points1;
    }
    
    
    /**
     *  Setzt den Namen.
     *
     *  @param  name1   Name der gesetzt werden soll
     */
    public void setName(String name1){
        name=name1;
    }
    
    /**
     *  Gibt die Punkte zur�ck.
     *
     *  @return Punktwert
     */
    public int getPoints(){
        return points;
    }
    
    
    /**
     *  Gibt den Namen zur�ck.
     *
     *  @return Name des Highscore-Eintrags
     */
    public String getName(){
        return name;
    }
    
}
