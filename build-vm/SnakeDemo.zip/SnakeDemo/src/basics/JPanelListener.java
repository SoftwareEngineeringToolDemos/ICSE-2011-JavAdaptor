package basics;

public interface JPanelListener {
	public void keyPressed(int arg0);
}
