/*
 * PointDistribution.java
 *
 * Created on 13. Februar 2008, 13:00
 *
 * Regelt die Punkteverteilung.
 */

package basics;

import entitys.Bug;
import entitys.Fly;
import entitys.Mouse;
import entitys.Slug;
import entitys.Centipede;

/**
 * Regelt die Punkteverteilung.
 *
 * @author Reimar Schr�ter, Alexander Grebhahn
 */
public class PointDistribution {
    
    private int pointsNow=0;
    private int pointsMax=0;
    
    /**
     * 
     * Creates a new instance of PointDistribution.
     */    
    public PointDistribution() {        
    }
    
    /**
     *
     * Gibt die Aktuelle PunkteAnzahl zur�ck.
     *
     * @return int
     */
    public int getPointsNow(){
        return pointsNow;
    }
    
    /**
     *
     * Gibt die Maximal errechte Punktezahl wieder.
     *
     * @return int
     */
    public int getPointsMax(){
        return pointsMax;        
    }
    
    /**
     *
     * Setzt die Maximale Punktezahl.
     *
     * @param neuePunktezahl
     */
    public void setPunkte(int neuePunktezahl){
        pointsNow=neuePunktezahl;
    }
    
    /*
     *
     *  Gleicht die aktuelle Punktzahl mit der maximalen ab. 
     *
     */
    private void pointsBalance(){
        if(pointsNow>pointsMax){
            pointsMax=pointsNow;
        }
    }
    
    /**
     * 
     * Ver�ndert die Punktezahl wenn man einen Tausendf��ler gegessen hat.
     * 
     * 
     * @param centi der Tausendf��ler
     */
    public void pointsCentipede(Centipede centi){
        if(centi.isAlive()){
            pointsNow+=100-centi.numberEatenSheets();
        }else{
            pointsNow+=50-(centi.maxRot()/2);
        }
        pointsBalance();
    }
    
    
    /**
     *
     * Ver�ndert die Punktezahl wenn man einen Bug gegessen hat.
     *
     * @param bug der Bug
     */
    public void pointsBug(Bug bug){
       pointsNow+=30;    
       pointsBalance();
    }
    
    
    /**
     *
     * Ver�ndert die Punktezahl wenn man einen Slug gegessen hat.
     *
     * @param slug der Slug
     */
    public void pointsSlug(Slug slug){
        pointsNow+=30;
        pointsBalance();
    }
    
    /**
     * 
     * Addiert zu den erreichten punkten noch welche f�r die �briggebliebenen lives.
     * 
     * 
     * @param lives die anzahl der Leben
     */    
    public void pointsRemaningLives(int lives){
        pointsNow+=lives*1000;
        pointsBalance();
    }
    
    /**
     *
     * Ver�ndert die Punktezahl wenn man eine Mouse gegessen hat.
     *
     * @param mouse die Mouse
     */
    public void pointsMouse(Mouse mouse){
        if(mouse.isAlive()){
            pointsNow+=125;
        }else{
            pointsNow+=75-mouse.getRot();
        }
        pointsBalance();
    }
    
    /**
     *
     * Ver�ndert die Punktezahl wenn man eine Fly gegessen hat.
     *
     * @param fly die Fly
     */
    public void pointsFly(Fly fly){
       pointsNow+=50+fly.getEndurance();
       pointsBalance();
    }
    
    
}
