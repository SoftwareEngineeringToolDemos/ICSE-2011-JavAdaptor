/*
 * Action.java
 *
 * Created on 24. November 2007, 22:44
 *
 * Die Klasse dient dazu, dass das in regelm��igen Zeitabst�nden das GameField aktualisiert wird.
 * Optional wird auch der Highscore bei neuer Menueauswahl aktualisiert.
 */
package basics;


import java.util.TimerTask;

/**
 * Die Klasse dient dazu, dass das GameField in regelm��igen Zeitabst�nden aktualisiert wird.
 * Optional wird auch der Highscore bei neuer Menueauswahl aktualisiert.
 *
 * @author  Alexander Grebhahn
 *          Reimar Schr�ter
 */
public class Action extends TimerTask{
            private boolean running=true;  //gibt an ob GameField aktualisiert werden soll
            private static GameField gameField; //GameField welches aktualisiert werden soll
            private Main main=null; //Main von der alles gesteuert wird bzw aufgerufen wird
            private boolean highRenew=false; // gibt an ob der highscore aktualisiert werden muss
            private int millis=160000; //zeitrate in der aktualisiert werden soll
            private long timeStart=System.currentTimeMillis(); // Startzeit 
            private long timeNow=timeStart; //vergangene zeit nach dem start
            
        
            
            /**
             * Erstellt eine Instanz der Klasse.
             *
             * @param main1 Main von dem alle Aktivit�ten gesteuert werden
             * @param gameFieldI �bergibt das neu zu zeichnende GameField 
             */
    	    public Action(Main main1,GameField gameFieldI){
                main=main1;
                gameField=gameFieldI;
	    }
            
            /**
             *  Erlaubt oder verbietet die Erneuerung des Highscore's.
             *
             *  @param  highRenew1  aktualisieren? (true -ja)
             */
            public void setHighscoreRenew(boolean highRenew1){
                highRenew=highRenew1;
            }
            
            /**
             *  Durch diese Methode wird eine Pause des Spiels erm�glicht.
             *
             *  beziehungsweise das Spiel fortgesetzt.
             * 
             */
	    public void changeRun(){
	    	running=!running;
	    }
            
            /**
             *  Durch diese Methode wird eine Pause des Spiels erm�glicht,
             *  beziehungsweise das Spiel fortgesetzt.
             *
             *  @param  running1 stopt das spiel mit false oder startet es wieder mit true
             */
            public void setRun(boolean running1){
                running=running1;
            }
            
            /**
             *  Setzt das GameField welches gesteuert werden soll.
             *
             *  @param gameField1 welches gesteuert werden soll
             */
            public void setGameField(GameField gameField1){
                gameField=gameField1;
            }
            
            /**
             *  Setzt die Zeitrate in der das Spiel aktualisiert werden soll.
             *
             *  @param millis1 Zeitrate f�r die Aktualisierung
             */
            public void setTimeMillis(int millis1){
                millis=millis1;
            }
            
	    /**
             * Wenn kein Pausenmodus ist und der Spieler nicht im Highscormenue ist, wird das GameField neu gemalt.
             *
             * Ansonsten wird der Highscore aktualisiert
             * 
             */        
	    public void run(){
	    	try{  
	    	if(!highRenew){
                if (running==true ){
                    timeNow=(System.currentTimeMillis())-timeStart;
                    if(millis<timeNow){
                        timeStart=System.currentTimeMillis();
                        if(gameField!=null)
                        	gameField.repaint();
                        }
                	}
              	}
              else{
          //      main.renewHighscoreView();
              }
            }catch (Exception e) {
			
            }
	    }
}

	