/*
 * QueueElement.java
 *
 * Created on 10. Februar 2008, 19:57
 *
 * Element der Queue
 */

package basics;

/**
 * Element der Queue
 *
 * @author  Alexander Grebhahn
 *          Reimar Schr�ter
 */
public class QueueElement {
    
    private int xIndex;
    private int yIndex;
    private QueueElement next = null;
    private int rekRequest;
    
    /**
     * Creates a new instance of QueueElement.
     *
     * @param xIndexI
     * @param yIndexI
     */
    public QueueElement(int xIndexI,int yIndexI) {
        xIndex=xIndexI;
        yIndex=yIndexI;
    }
    
    /**
     * Creates a new instance of QueueElement.
     *
     * @param xIndexI
     * @param yIndexI
     * @param rekRequestI anzahl der rekursiven Durchl�ufe
     */
    public QueueElement(int xIndexI,int yIndexI, int rekRequestI) {
        xIndex=xIndexI;
        yIndex=yIndexI;
        rekRequest=rekRequestI;
    }
    
    /**
     * Gibt die Anzahl der rekursiven Durchl�ufe zur�ck, die ben�tigt wurden um das Element zu erstellen.
     *
     * @return anzahl der Durchl�ufe
     */
    public int getRekRequest(){
        return rekRequest;
    }
    
    
    /**
     * Gibt den xIndex zur�ck.
     *
     * @return xIndex
     */
    public int getxIndex(){
        return xIndex;
    }
    
    /**
     * Gibt den yIndex zur�ck.
     *
     * @return yIndex
     */
    public int getyIndex(){
        return yIndex;
    }
    
    /**
     * Verkn�pft das Element mit seinem N�chsten.
     * 
     * @param nextI 
     */    
    public void setNext(QueueElement nextI){
        next=nextI;
    }
    
    /**
     * Gibt das n�chste Element wieder.
     * 
     * @return n�chstes Element
     */
    public QueueElement getNext(){
        return next;
    }
    
}
