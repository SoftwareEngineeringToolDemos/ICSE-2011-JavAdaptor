/*
 * Queue.java
 *
 * Created on 10. Februar 2008, 20:01
 *
 * Queue
 */

package basics;

/**
 * Queue
 *
 * @author  Alexander Grebhahn
 *          Reimar Schr�ter
 */
public class Queue {
    
    private QueueElement first;
    private QueueElement last;
    /**
     * Creates a new instance of Queue.
     */
    
    public Queue() {
    }

    /**
     *  F�gt an die Liste ein Element an.
     * 
     * 
     * @param newElement Element welches angef�gt werden soll
     */
    public void addLast(QueueElement newElement){
        if(first==null){
            first=newElement;
            last=newElement;
        }else{
            last.setNext(newElement);
            last=last.getNext();
        }
        
    }
    
    /**
     * Gibt das erste Element in der Warteschlange wieder und entfernt es. 
     *
     * @return erstes Element der Queue
     */
    public QueueElement getAndRemoveFirst(){
        QueueElement tmp= first;
        first=first.getNext();
        return tmp;
    } 
    
    /**
     * Gibt zur�ck ob die Queue leer ist.
     *
     * @return queue Leer?
     */
    public boolean isEmpty(){
        if(first==null){
            return true;
        }
        return false;
    }
}
