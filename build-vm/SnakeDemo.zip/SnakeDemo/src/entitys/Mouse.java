/*
 * Mouse.java
 *
 * Created on 14. Februar 2008, 11:16
 *
 * Of mouse and snake.
 */

package entitys;

import basics.Field;
import basics.MyMath;
import java.util.Random;

/**
 * Verwirklichung einer Maus.
 *
 * @author Reimar Schr�ter, Alexander Grebhahn
 */
public class Mouse extends Entity{
    
    private int mouseRoute;
    private int xPosI;
    private int yPosI;
    private int xPosII;
    private int yPosII;
    private boolean headAlive=true;
    private boolean taleAlive=true;
    private int doSomething=0;
    private int rot=-1;
    
    private Random rand;
    private MyMath myMath;
    private int maxEndurance=12;
    private int endurance=maxEndurance;
    private int faktor=1;
    private int stepsize=9;
    
    
    /** 
     * Creates a new instance of Mouse.
     *
     * @param route 
     * @param xPos
     * @param yPos 
     */
    public Mouse(int route, int xPos, int yPos,int faktor) {
    	this.faktor=faktor;
    	stepsize=stepsize*faktor;
        myMath= new MyMath();
        rand = new Random();
        mouseRoute=route;
        xPosI=xPos;
        yPosI=yPos;
        if(route==0){
            xPosII=xPosI;
            yPosII=yPosI+(9*faktor);
        }
        if(route==1){
            xPosII=xPosI-(9*faktor);
            yPosII=yPosI;        
        }
        if(route==2){
            xPosII=xPosI;
            yPosII=yPosI-(9*faktor);        
        }
        if(route==3){
            xPosII=xPosI+(9*faktor);
            yPosII=yPosI;        
        }
    }
    
    public int stepsize(){
    	return stepsize;
    }
    /**
     *
     * Gibt zur�ck das es sich bei den Entity um eine Mouse handelt.
     *
     * @return Mouse
     */    
    public String isA(){
        return "Mouse";
    }
    
    /**
     *
     * Simmuliert eine Bewegung.
     *
     * @param field das Spielfeld
     * @param snake die Snake
     */
    public void oneStep(Field field,Snake snake){
        if(this.isAlive()){
            //Entscheiden
            doSomething=0; // 0 bedeutet macht nichts
            int dist = myMath.getDist(snake.getxPos(),snake.getyPos(),this.getxPos(),this.getyPos());
            if(dist<= 27 ){
                doSomething=2; // 2 bedeutet hat angst
            }
            if((Math.abs(rand.nextInt())%4 == 0) && (doSomething ==0)){
                doSomething=1; // 1 bedeutet langweilig
            }
                        
           
            //relax
            if(doSomething==0){
                relax();
            }
            // zuf�lliges Bewegen
            if(doSomething==1){
                int route = Math.abs(rand.nextInt())%4;
                if(nextFieldWalkable(field,route)){
                    moveRoute(route);
                }
            }
            //wegrennen (ganze einfach die distanze Vergr��ern)
            if(doSomething==2 && endurance>0 && snake.alreadyMoved()){
                endurance--;
                // distanzen zur Schlange ermitteln
                int distFieldAbove=0;
                int distFieldDown=0;
                int distFieldLeft=0;
                int distFieldRight=0;
                if(yPosI-(9*faktor)>0){
                    if(field.getWalkableAbsolutPos(xPosI,yPosI-(9*faktor))){
                        distFieldAbove = myMath.getDist(snake.getxPos(),snake.getyPos(),xPosI,yPosI-(9*faktor));
                    }
                }
                if((xPosI+(9*faktor))/(9*faktor) < field.getIndexX()-1){
                    if(field.getWalkableAbsolutPos(xPosI+(9*faktor),yPosI)){
                        distFieldRight = myMath.getDist(snake.getxPos(),snake.getyPos(),xPosI+(9*faktor),yPosI);
                    }
                }
                if((yPosI+(9*faktor))/(9*faktor) < field.getIndexY()-1){
                    if(field.getWalkableAbsolutPos(xPosI,yPosI+(9*faktor))){
                        distFieldDown = myMath.getDist(snake.getxPos(),snake.getyPos(),xPosI,yPosI+(9*faktor));
                    }
                }
                if(xPosI-(9*faktor)>0){
                    if(field.getWalkableAbsolutPos(xPosI-(9*faktor),yPosI)){
                        distFieldLeft = myMath.getDist(snake.getxPos(),snake.getyPos(),xPosI-(9*faktor),yPosI);
                    }
                }
                
                //Maximum davon ermitteln
                int route = myMath.maximumDistance(distFieldAbove,distFieldRight,distFieldDown,distFieldLeft)-1;                
                if(route<4){
                    moveRoute(route);
                }
            }
        }else{
            rot();
        }
    }
    
    private boolean nextFieldWalkable(Field field,int route){
        if(route==0){
            if(yPosI-(9*faktor)>0){
                if(field.getTileAbsolutPos(xPosI,yPosI-(9*faktor)).getWakable()){
                    return true;
                }
            }
        }
        if(route==1){
            if((xPosI+(9*faktor))/(9*faktor) < field.getIndexX()-1){
                if(field.getTileAbsolutPos(xPosI+(9*faktor),yPosI).getWakable()){
                    return true;
                }
            }
        }
        if(route==2){
            if((yPosI+(9*faktor))/(9*faktor) < field.getIndexY()-1){
                if(field.getTileAbsolutPos(xPosI,yPosI+(9*faktor)).getWakable()){
                    return true;
                }
            }
        }
        if(route==3){
            if(xPosI-(9*faktor)>0){
                if(field.getTileAbsolutPos(xPosI-(9*faktor),yPosI).getWakable()){
                    return true;
                }
            }
        }
        return false;
    }

    private void moveRoute(int route){
        xPosII=xPosI;
        yPosII=yPosI;
        mouseRoute=route;
        if(route == 0){
            yPosI=yPosI-(9*faktor);
        }
        if(route == 1){
            xPosI=xPosI+(9*faktor);
        }
        if(route == 2){
            yPosI=yPosI+(9*faktor);
        }
        if(route == 3){
            xPosI=xPosI-(9*faktor);
        }   
    } 
    
    /**
     *
     * Gibt die absolute X Position des Mousekopfes zur�ck.
     *
     * @return xPos
     */
    public int getxPos() {
        return xPosI;
    }
    
    /**
     *
     * Gibt die absolute Y Position des Mousekopfes zur�ck.
     *
     * @return yPos
     */
    public int getyPos() {
        return yPosI;
    }
    
    /**
     *
     * Gibt die absolute X Position des Mouseschwanzes zur�ck.
     *
     * @return xPos
     */
    public int getxPosII() {
        return xPosII;
    }
    
    /**
     *
     * Gibt die absolute Y Position des Mouseschwanzes zur�ck.
     *
     * @return yPos
     */
    public int getyPosII() {
        return yPosII;
    }
    
    /**
     *
     * Gibt die minimum X-Position des MouseKopf zur�ck.
     *
     *  @return xPos 
     */
    public int getminXPos(){
        return xPosI-(5*faktor);
    }
    
    /**
     *
     * Gibt die minimum Y-Position des MouseKopf zur�ck.
     *
     *  @return yPos
     */
    public int getminYPos(){
        return yPosI-(5*faktor);
    }
    
    /**
     *
     * Gibt die minimum X-Position des MouseTale zur�ck.
     *
     *  @return xPos
     */
    public int getminXPosII(){
        return xPosII-(5*faktor);
    }
    
    /**
     *
     *  Gibt die minimum Y-Position des MouseTale zur�ck.
     *
     *  @return yPos
     */
    public int getminYPosII(){
        return yPosII-(5*faktor);
    }
    
    /**
     *
     * Gibt die Richtung der Mouse zur�ck.
     *
     * @return route
     */
    public int getRoute(){
        return mouseRoute;
    }
    
    /**
     *
     * Gibt zur�ck ob die Mouse lebt.
     * 
     * @return lebt?
     */
    public boolean isAlive(){
        return headAlive && taleAlive;
    }
    
    /**
     *
     * Gibt die Richtung der Mouse zur�ck.
     *
     * @return route
     */
    public int getMouseRoute() {
        return mouseRoute;
    }
    
    /**
     * 
     * Wird benutzt um den Kopf der Mouse auf getressen zu setzen.
     *
     * 
     */
    public void headEat(){
        headAlive=false;        
    }
    
    /**
     *
     * Gibt zur�ck ob der Kopf der Mouse noch existiert.
     *
     * @return kopf existend?
     */
    public boolean headAlive(){
        return headAlive;
    }
    
    /**
     *
     * Wird benutzt um den Schwanz der Mouse auf getressen zu setzen.
     *
     */
    public void taleEat(){
        taleAlive=false;        
    }
    
    /**
     *
     * Gibt zur�ck ob der Schwanz der Mouse noch existiert.
     *
     * @return Schwanz existend?
     */
    public boolean taleAlive(){
        return taleAlive;
    }
    
    /*
     *
     * L�sst die Ausdauer der Mouse wieder regenerieren.
     *
     */
    private void relax() {
        if(endurance<maxEndurance){
            endurance++;
        }
    }
    
    /*
     * 
     * L�sst den rest der Mouse verwesen.
     *
     */
    private void rot(){
        if(rot< 75){
            rot++;
        }
    }
    
    /**
     *
     * Gibt die Verwsung wieder.
     *
     * @return die Verwesung
     */
    public int getRot(){
        return rot;
    }
}