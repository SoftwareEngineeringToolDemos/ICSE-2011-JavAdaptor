/*
 * Entity.java
 *
 * Created on 21. Januar 2008, 23:44
 *
 * Das Interface der Entitys
 */

package entitys;

import java.util.Random;

import basics.Field;
import basics.GameField;
import basics.MyMath;
import basics.QueueElement;

/**
 *  Das Interface der Entitys.
 *
 * @author Reimar Schr�ter,
 *         Alexander Grebhahn
 */
public class Entity {
    
    /** 
     * Creates a new instance of Entity
     *
     */
    public Entity() {
    }
    
    /**
     * 
     * Gibt die Art des Entitys zur�ck.
     *
     * @return Entity
     */
    public String isA(){
        return "Entity";
    }
    
    /**
     *
     * Simuliert eine Bewegung.
     *
     */
    public void oneStep(Field field){
        
    }

    /**
     *
     * x Position des Entitys.
     *
     * @return xPos
     */
    public int getxPos() {
        return 0;
    }

    
    /**
     *
     * y Position des Entitys.
     *
     * @return yPos
     */
    public int getyPos() {
        return 0;
    }
    
   
    
}
