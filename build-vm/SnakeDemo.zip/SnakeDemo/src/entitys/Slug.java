/*
 * Slug.java
 *
 * Created on 17. Januar 2008, 16:12
 *
 * Slug 
 *
 */

package entitys;

import basics.Field;
import java.util.Random;

/**
 * Verwirklichung einer Schnecke.
 *
 * @author Reimar Schr�ter, Alexander Grebhahn
 * 
 */
public class Slug extends Entity{
    
    private int maxSlimeLength;
    private SlugPart head;
    private int stepsize = 3;
    private Random rand;
    private int faktor=1;
    
    /**
     * Creates a new instance of Slug.
     * 
     * @param xPosI
     * @param yPosI
     * @param maxSlimeLengthI
     * @param routeI
     */
    public Slug(int xPosI,int yPosI,int maxSlimeLengthI,int routeI,int faktor) {
      this.faktor=faktor;
      stepsize=faktor*stepsize;
      maxSlimeLength=maxSlimeLengthI;
      rand= new Random();
      head = new SlugPart("slug",xPosI,yPosI,faktor);
      head.setRoute(routeI);
      SlugPart slime = new SlugPart("slime",xPosI,yPosI,faktor);
      head.setNext(slime);
    }
    /**
     *
     * Gibt Slug als String zur�ck um das Entity als Slug zu identifizieren.
     *
     * @return Slug
     */
    public String isA(){
        return "Slug";
    }
    
    public int stepsize(){
    	return stepsize;
    }
    
    /** 
     *
     * Simmuliert eine Bewegung.
     *
     * @param field das Feld
     */
    public void oneStep(Field field){
        
        think(field);
        toAge();
        if(head.getRoute()==0){
            head.yPos=head.yPos-stepsize;
        }
        if(head.getRoute()==1){
            head.xPos=head.xPos+stepsize;
        }
        if(head.getRoute()==2){
            head.yPos=head.yPos+stepsize;
        }
        if(head.getRoute()==3){
            head.xPos=head.xPos-stepsize;
        }     
    }
    
    
    private void getlength(){
        SlugPart tmp=head;
        int count=1;
        while(tmp.getNext()!=null){
            count++;
            tmp=tmp.getNext();
        }
    }
    
    /**
     *
     * Gibt die slug(als SlugPart) zur�ck.
     *
     * @return die Slug
     */
    public SlugPart getHead(){
        return head;
    }

    private void think(Field field) {
        if(field.isCenterOfTile(head.getxPos()) && field.isCenterOfTile(head.getyPos())){
            int tmp = Math.abs(rand.nextInt()%(9*faktor));
            if(tmp==1){
                if((head.getyPos()-(9*faktor))/(9*faktor) >0){
                    if(field.getTileAbsolutPos(head.getxPos(),head.getyPos()-(9*faktor)).getWakable()){
                        head.setRoute(0);
                    }
                }
            }
            if(tmp==2){
                if((head.getxPos()+(9*faktor))/(9*faktor) < field.getIndexX()-1){
                    if(field.getTileAbsolutPos(head.getxPos()+(9*faktor),head.getyPos()).getWakable()){
                        head.setRoute(1);
                    }
                }    
            }
            if(tmp==3){
                if((head.getyPos()+(9*faktor))/(9*faktor) < field.getIndexY()-1){               
                    if(field.getTileAbsolutPos(head.getxPos(),head.getyPos()+(9*faktor)).getWakable()){
                        head.setRoute(2);
                    }
                }
            }
            if(tmp==4){
                if((head.getxPos()-(9*faktor))/(9*faktor) >0){
                    if(field.getTileAbsolutPos(head.getxPos()-(9*faktor),head.getyPos()).getWakable()){
                        head.setRoute(3);
                    }
                }
            }
            borderTest(field);
        }
        if(!nextFieldWalkable(field)){
            //umdrehen
            vrsTurnClockwiseDirection();
            vrsTurnClockwiseDirection();
        }

    }    

    private void borderTest(Field field){
        if(head.getxPos()==(4*faktor)){
           head.setRoute(1);
        }
        if(head.getyPos()==(4*faktor)){
            head.setRoute(2);
        }
        if((field.getIndexX()*(9*faktor))-(5*faktor)==head.getxPos()){
            head.setRoute(3);
        }
        if((field.getIndexY()*(9*faktor))-(5*faktor)==head.getyPos()){
            head.setRoute(0);
        }
    }
    
    private void toAge() {
        SlugPart tmp=head.getNext();
        SlugPart newPart = new SlugPart("slime",head.getxPos(),head.getyPos(),faktor);
        head.setNext(newPart);
        newPart.setNext(tmp);
        
        SlugPart cycle =head.getNext();
        while(cycle.getNext()!=null){
            cycle.incAge();
            if(cycle.getAge()==maxSlimeLength){
                cycle.setNext(null);
            }else{
                cycle=cycle.getNext();       
            }
        }
    }
    
    /* 
     * 
     * Dreht die Slug in Uhrzeigerrichtung.
     *
     */
    private void turnClockwiseDirection(){
        if(head.getRoute()==3){
            head.setRoute(0);
        }
        else{
            head.setRoute(head.getRoute()+1);
        }    
    }
    
    /* 
     * 
     * Dreht die Slug gegen die Uhrzeigerrichtung.
     *
     */
    private void vrsTurnClockwiseDirection(){
        if(head.getRoute()==0){
            head.setRoute(3);
        }
        else{
            head.setRoute(head.getRoute()-1);
        }
    }
    /*
     *
     * �berpr�ft ob das n�chste Feld walkable ist.
     *
     */
    private boolean nextFieldWalkable(Field field){
        if(head.getRoute()==0){
           if(field.getTileAbsolutPos(head.getxPos(),head.getyPos()-stepsize).getWakable()){
               return true;
           }
        }
        if(head.getRoute()==1){
           if(field.getTileAbsolutPos(head.getxPos()+stepsize,head.getyPos()).getWakable()){
               return true;
           }
        }
        if(head.getRoute()==2){
           if(field.getTileAbsolutPos(head.getxPos(),head.getyPos()+stepsize).getWakable()){
               return true;
           }
        }
        if(head.getRoute()==3){
           if(field.getTileAbsolutPos(head.getxPos()-stepsize,head.getyPos()).getWakable()){
               return true;
           }
        }
        return false;
    }
    
    /**
     *
     * Gibt die xPos der Slug zur�ck.
     *
     * @return xPos 
     */
    public int getxPos(){
        return head.xPos;
    }
    
    /**
     *
     * Gibt die yPos der Slug zur�ck.
     *
     * @return xPos 
     */
    public int getyPos(){
        return head.yPos;
    }
    
}
