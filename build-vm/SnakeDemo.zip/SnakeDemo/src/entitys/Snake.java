

package entitys;

import basics.Field;
import entitys.SnakePart;

public class Snake extends Entity{
    
    private int factor=1;
    private int stepsize=11;
    private SnakePart tail;
    private SnakePart head;
    private boolean alreadyMoved=false;
    private boolean holearrived=false;
    
    // TODO update4 holeArrived
//    private boolean inHole = false;
 
    public Snake(int xPosAtStart,int yPosAtStart,int numberOfPartsAtStart,int factor) {
    	System.out.println("Snake: "+this);
    	
    	this.factor=factor;
    	stepsize=stepsize*factor;
        head = new SnakePart("head",xPosAtStart,yPosAtStart,stepsize);
        tail = new SnakePart("tail",xPosAtStart,yPosAtStart,stepsize);
        head.setNext(tail);
        for(int laufAnzahlderMittelteilebeimStart=0;laufAnzahlderMittelteilebeimStart<numberOfPartsAtStart;laufAnzahlderMittelteilebeimStart++){
            SnakePart middle =new SnakePart("middle",xPosAtStart,yPosAtStart,stepsize);
            SnakePart hilfeZumEinfuegen = head.getNext();
            head.setNext(middle);
            head.getNext().setNext(hilfeZumEinfuegen);
        }
    }
    
    public int getSize(){
    	return stepsize;
    }
    
    public SnakePart getHead(){
        return this.head;
    }
    
    public SnakePart getTale(){
        return this.tail;
    }
    
    public String isA(){
        return "Snake";
    }
 
    public void eat(){
        SnakePart tmp= head.getNext();
        SnakePart neu = new SnakePart("middle",head.getxPos(),head.getyPos(),head.getPartsize());
        neu.setRoute(head.getRouteInt());
        head.setNext(neu);
        neu.setNext(tmp);
    }
    
    public int fullSize(){
        SnakePart cycle = head;
        int count=1;
        while(cycle.getNext()!=null){
            count++;
            cycle=cycle.getNext();
        }
        return count;
    }
    
    /**
     *
     * Gibt Richtung der Schlange zur�ck.
     *
     * @return route der Schlange
     *
     */
    public int getRouteInt(){
        return head.getRouteInt();
    }
    
    /**
     *
     * Gibt die xPosition des Schlange Kopfes zur�ck.
     *
     * return x-Position der Schlange
     *
     */
    public int getxPos(){
        return head.getxPos();
    }
    
    /**
     *
     * Gibt die yPosition des Schlange Kopfes zur�ck.
     *
     * return y-Position der Schlange
     *
     */
    public int getyPos(){
        return head.getyPos();
    }
    
    /**
     *
     * Gibt die Richtung der Schlange zur�ck.
     *
     * return richtung der Schlange
     *
     */
    public String getRouteString(){
        return head.getRouteString();
    }
    
    /**
     * 
     * Ver�ndert die Richtung der Schlange.
     * 
     * 
     * @param route int neue Richtung der Schlange
     */
    public void setRouteInt(int route){
        alreadyMoved=true;
        head.setRoute(route);
    }
    
    /**
     *
     * Dreht den Kopf der Schlange in Uhrzeigerrichtung.
     *
     */
    public void turnClockwiseDirection(){
        if(head.getRouteInt()==3){
            head.setRoute(0);
        } else{
            head.setRoute(head.getRouteInt()+1);
        }
    }
    
    /**
     *
     * Dreht den Kopf der Schlange gegen die Uhrzeigerrichtung.
     *
     */
    public void vrsTurnClockwiseDirection(){
        if(head.getRouteInt()==0){
            head.setRoute(3);
        } else{
            head.setRoute(head.getRouteInt()-1);
        }
    }
    
    public void oneStep(Field field,int countEntity){
    	if(alreadyMoved){
            
        	
    	// TODO update4 holeArrived
    	/*
            if(this.fullSize()>13){
    			if(head.getxPos()==field.getXHoleSnake() && head.getyPos()==field.getYHoleSnake()){
                    holearrived=true;
                    if(tail.getxPos()==field.getXHoleSnake() && tail.getyPos()==field.getYHoleSnake()){
                        inHole=true;
                    }
                }
            }
            //*/
    		//End
        	
            SnakePart cycle = tail;
            field.setWalkableAbsolutPos(cycle.getxPos(),cycle.getyPos(),true);
            while(cycle.getPrev()!=null){
            	if(!cycle.getTyp().equals("head")){
            		cycle.setxPos(cycle.getPrev().getxPos());
                    cycle.setyPos(cycle.getPrev().getyPos());
                    cycle.setRoute(cycle.getPrev().getRouteInt());
                    cycle=cycle.getPrev();
            	}
            }
            field.setWalkableAbsolutPos(head.getxPos(),head.getyPos(),false);
            if(!holearrived){
                if(this.getRouteInt()==0){
                    head.setyPos(head.getyPos()-(stepsize-(2*factor)));
                }else{
                    if(this.getRouteInt()==1){
                        head.setxPos(head.getxPos()+(stepsize-(2*factor)));
                    }else{
                        if(this.getRouteInt()==2){
                            head.setyPos(head.getyPos()+(stepsize-(2*factor)));
                        }else{
                            if(this.getRouteInt()==3){
                                head.setxPos(head.getxPos()-(stepsize-(2*factor)));
                            }
                        }
                    }
                }
            }
        }        
    }
    
    public boolean alreadyMoved(){
        return alreadyMoved;
    }
    
    public void routeFlow(){
        SnakePart cycle = this.getHead();
        int route= cycle.getRouteInt();
        while(cycle.getNext()!=null){
            cycle=cycle.getNext();
            cycle.setRoute(route);
        }
    }
    
    public boolean getHoleArrived(){
        return holearrived;
    }
  
    /**
     * Setzt den Kopf der Schlange.
     *
     * @param head Kopf der Schlange
     */
    public void setHead(SnakePart head) {
        this.head = head;
    }
    
}
