/*
 * CentiPart.java
 *
 * Created on 25. Januar 2008, 12:51
 *
 * Die einzelnen Teile des Tausendf��lers.
 */

package entitys;

/**
 * Die einzelnen Teile des Tausendf��lers.
 *
 * @author Reimar Schr�ter,
 *         Alexander Grebhahn
 *
 */
public class CentiPart {
    
    private boolean isAlive= true;
    private int xPos;
    private int yPos;
    private int route;
    private int partsize=9;
    private int deadSince=0;
    private int faktor=1;
    
    /**
     * Creates a new instance of CentiPart.
     *
     * @param routeI die Richtung des Teils
     * @param xPosI die XPosition
     * @param yPosI die yPosition
     */
    public CentiPart(int routeI,int xPosI,int yPosI,int faktor) {
    	this.faktor=faktor;
    	partsize=partsize*faktor;
        xPos=xPosI;
        yPos=yPosI;
        route=routeI;
    }
    
    /**
     * Gibt wieder ob der Part am leben ist.
     *
     * @return am leben?   
     */
    public boolean isAlive(){
        return isAlive;
    }
    
    /**
     * Das Teil wird gegessen.
     * 
     */
    public void isEaten(){
        isAlive=false;
        deadSince++;
    }
    
    /**
     * erh�ht die Zeit die der Tausendf��ler tot is.
     * 
     */
    public void incRot(){
        deadSince++;
        if(deadSince>100){
            deadSince=100;
        }
    }
    
    /**
     * Gibt die xPosition des Part zur�ck.
     *
     * @return xPos
     * 
     */
    public int getxPos(){
        return xPos;
    }
    
    /**
     * Gibt die yPosition des Part zur�ck.
     *
     * @return yPos
     * 
     */
    public int getyPos(){
        return yPos;
    }
    
    /**
     * Setzt die neue xPosition.
     *
     * @param newPos
     *
     */
    public void setxPos(int newPos){
        xPos= newPos;
    }
    
    /**
     * Setzt die neue yPosition.
     *
     * @param newPos
     *
     */
    public void setyPos(int newPos){
        yPos= newPos;
    }
    
        
    /**
     * Setzt die neue Richtung.
     *
     * @param newRoute
     *
     */
    public void setRoute(int newRoute){
        route= newRoute;
    }
    
    /**
     * Gibt die Richtung des Part zur�ck.
     *
     * @return route
     */
    public int getRoute(){
        return route;
    }
    
    
    /**
     * Gibt die minimum xPosition des Part zur�ck.
     *
     * @return minimum X-Position
     * 
     */
    public int getminxPos(){
        return xPos-(int)partsize/2;
    }
    
    /**
     * Gibt die minimum yPosition des Part zur�ck.
     *
     * @return minimum X-Position
     * 
     */
    public int getminyPos(){
        return yPos-(int)partsize/2;
    }
    
    /**
     * Gibt an, wieviel prozent schon Verwest sind.
     */
    public int getRot(){
        return deadSince;
    }
}
