/*
 * Bug.java
 *
 * Created on 20. Januar 2008, 17:41
 *
 * There is no bug only a Bug.
 * It's not a bug it's a feature.
 */

package entitys;

import basics.Field;

import basics.GameField;
import basics.Main;
import basics.MyMath;

import java.util.Random;

public class Bug 
//TODO update3 moreEntitys
//extends Entity
{

    private int factor=1;
    private int xPos;
    private int yPos;
    private int status=0;
    protected int route;
    private Random rand;    
    private int stepsize=3;

    public Bug(int xPosI,int yPosI,int routeI,int factor) {
    	System.out.println(this);
    	this.factor=factor;
    	stepsize=stepsize*factor;
    	xPos=xPosI;
        yPos=yPosI;
        route=routeI;
        rand = new Random();
    }

    public int stepsize(){
    	return stepsize;
    }
    
    public void oneStep(Field field){
        status++;
        think(field);
        if(route==0){
            yPos=yPos-stepsize;
        }
        if(route==1){
            xPos=xPos+stepsize;
        }
        if(route==2){
            yPos=yPos+stepsize;
        }
        if(route==3){
            xPos=xPos-stepsize;
        }
    }
    
    /*
     *
     */
    private void think(Field field){       
        if(field.isCenterOfTile(xPos) && field.isCenterOfTile(yPos)){
            int tmp = Math.abs(rand.nextInt()%7);
            if(tmp==1){
                if((yPos-(9*factor))/(9*factor) >0){
                    if(field.getTileAbsolutPos(xPos,yPos-(9*factor)).getWakable()){
                        route=0;
                    }
                }
            }    
            if(tmp==2){
                if((xPos+(9*factor))/(9*factor) < field.getIndexX()-1){
                    if(field.getTileAbsolutPos(xPos+(9*factor),yPos).getWakable()){
                        route=1;
                    }
                }
            }
            if(tmp==3){
                if((yPos+(9*factor))/(9*factor) < field.getIndexY()-1){                    
                    if(field.getTileAbsolutPos(xPos,yPos+(9*factor)).getWakable()){
                        route=2;
                    }
                } 
            }
            if(tmp==4){
                if((xPos-(9*factor))/(9*factor) >0){
                    if(field.getTileAbsolutPos(xPos-(9*factor),yPos).getWakable()){
                        route=3;
                    }
                }  
            }
            borderTest(field);            
        
            if(!nextFieldWalkable(field)){
            	vrsTurnClockwiseDirection();
            	vrsTurnClockwiseDirection();
            }
        }
    }
        
    
    private void borderTest(Field field){
    	Main.sysout("x-pos in border "+xPos);
        if(xPos==(4*factor)){
           route=1;
        }
        if(yPos==(4*factor)){
            route=2;
        }
        if((field.getIndexX()*(9*factor))-(5*factor)==xPos){
            route=3;
        }
        if((field.getIndexY()*(9*factor))-(5*factor)==yPos){
            route=0;
        }
    }
    
    /**
     *
     * �berpr�ft ob das n�chste Feld walkable ist.
     *
     */
    private boolean nextFieldWalkable(Field field){
        if(route==0){
           if(field.getTileAbsolutPos(xPos,yPos-stepsize).getWakable()){
               return true;
           }
        }
        if(route==1){
           if(field.getTileAbsolutPos(xPos+stepsize,yPos).getWakable()){
               return true;
           }
        }
        if(route==2){
           if(field.getTileAbsolutPos(xPos,yPos+stepsize).getWakable()){
               return true;
           }
        }
        if(route==3){
           if(field.getTileAbsolutPos(xPos-stepsize,yPos).getWakable()){
               return true;
           }
        }
        return false;
    }
    
    /**
     * 
     * Ver�ndert die X-Position des Bug.
     * 
     * @param newPos
     */
    public void setXPos(int newPos){
        xPos=newPos;
    }
    
    /**
     * 
     * Ver�ndert die Y-Position des Bug.
     * 
     * @param newPos
     */
    public void setYPos(int newPos){
        yPos=newPos;
    }
    
    /**
     *
     *gibt die X-Position des Bug zur�ck.
     *  @return int
     */
    public int getxPos(){
        return xPos;
    }
    
    /**
     *
     *gibt die Y-Position des Bug zur�ck.
     *  @return int
     */
    public int getyPos(){
        return yPos;
    }
    
    /**
     * 
     * Ver�ndert die Richtung des Bug.
     * 
     * @param newRoute
     */
    public void setRoute(int newRoute){
        route=newRoute;
    }
    
    /**
     *
     *gibt die Richtung des Bug zur�ck.
     *  @return route
     */
    public int getRoute(){
        return route;
    }
    
    /**
     *
     * gibt des Laufsteatus des Bug zur�ck.
     * @return int
     */
    public int getStatus(){
        return status;
    }
    
    /**
     *
     *gibt die minimum X-Position des Bug zur�ck.
     *  @return int
     */
    public int getminXPos(){
        return xPos-(5*factor);
    }
    
    /**
     *
     *gibt die minimum Y-Position des Bug zur�ck.
     *  @return int
     */
    public int getminYPos(){
        return yPos-(5*factor);
    }
    
    /**
     *
     *gibt Bug als String zur�ck um das Entity als Bug zu identifizieren.
     *
     */
    public String isA(){
        return "Bug";
    }
    
   
    private void turnClockwiseDirection(){
        if(route==3){
            route=0;
        }
        else{
            route++;
        }    
    }
    
   
    private void vrsTurnClockwiseDirection(){
        if(route==0){
            route=3;
        }
        else{
            route--;
        }
    }
    
  //TODO update3 moreEntitys
    /*
    public static Entity newEntity(Random rand,int factor,Field field,Snake snake, boolean[][] fieldwithoutEntitys){
        GameField.countEntity--;
        int route = Math.abs(rand.nextInt()%4);
        
        EntityHelpings entityhelp = new EntityHelpings(field, rand, factor);
        
        int random = rand.nextInt();
        
        if(random%2 == 0){
            int abs;
            int[] position;
            
            do{
                position = entityhelp.walkableRandomFieldIndex();
                abs = MyMath.getDist(snake.getxPos(),snake.getyPos(),position[0]*(9*factor),position[1]*(9*factor));   
                
            }while(abs<27);
            
            Bug bug = new Bug((position[0]*(9*factor))+(4*factor),(position[1]*(9*factor))+(4*factor),route,factor);
            return bug;
       
        }
        if(random%2 == 1){
            int[] position = entityhelp.walkableRandomFieldIndex();
            Fly fly= new Fly((position[0]*(9*factor))+(4*factor),(position[1]*(9*factor))+(4*factor),route,factor);
            return fly;
        }
        return null;
    }
   //*/
    
    
}
