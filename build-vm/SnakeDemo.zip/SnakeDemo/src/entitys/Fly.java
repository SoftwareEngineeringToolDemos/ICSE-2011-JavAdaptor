/*
 * Fly.java
 *
 * Created on 26. Februar 2008, 15:39
 *
 * Fly
 */

package entitys;

import basics.Field;
import basics.QueueElement;
import basics.MyMath;
import java.util.Random;

/**
 * Verwirklichung einer Fliege.
 *
 * @author Reimar Schr�ter, Alexander Grebhahn
 */
public class Fly extends Entity{
    
    private int route;
    private int xPos;
    private int yPos;
    private int endurance=25;
    private int maxEndurance=35;
    private int stepsize=3;
    private boolean isFlying=false;
    
    private int xPosAim;
    private int yPosAim;
    private int faktor=1;
    
    
    public int getxPosAim() {
		return xPosAim;
	}

	public int getyPosAim() {
		return yPosAim;
	}

	/** 
     * Creates a new instance of Fly.
     *
     * @param xPosI die xPosition
     * @param yPosI die yPosition
     * @param routeI die Richtung der Fly
     */
    public Fly(int xPosI,int yPosI,int routeI,int faktor) {
    	stepsize=stepsize*faktor;
    	this.faktor=faktor;
            route=routeI;
            xPos=xPosI;
            yPos=yPosI;
    }
    
    public int stepsize(){
    	return stepsize;
    }
    
    /**
     * 
     * Ver�ndert die X-Position der Fly.
     * 
     * @param newPos
     */
    public void setXPos(int newPos){
        xPos=newPos;
    }
    
    /**
     * 
     * Ver�ndert die Y-Position der Fly.
     * 
     * @param newPos
     */
    public void setYPos(int newPos){
        yPos=newPos;
    }
    
    /**
     *
     *gibt die X-Position der Fly zur�ck.
     *  @return xPos
     */
    public int getxPos(){
        return xPos;
    }
    
    /**
     *
     *gibt die Y-Position der Fly zur�ck.
     *  @return yPos
     */
    public int getyPos(){
        return yPos;
    }
    
    /**
     * 
     * Ver�ndert die Richtung der Fly.
     * 
     * @param newRoute
     */
    public void setRoute(int newRoute){
        yPos=newRoute;
    }
    
    /**
     *
     *gibt die Richtung der Fly zur�ck.
     *  @return route
     */
    public int getRoute(){
        return route;
    }
    
    /**
     *
     *gibt die minimum X-Position der Fly zur�ck.
     *  @return minimale x Position
     */
    public int getminXPos(){
        return xPos-(5*faktor);
    }
    
    /**
     *
     *Gibt die minimum Y-Position der Fly zur�ck.
     * 
     * @return minimale y Position
     */
    public int getminYPos(){
        return yPos-(5*faktor);
    }
    
    /**
     *
     * Gibt Fly als String zur�ck um das Entity als Fly zu identifizieren.
     *
     * @return Fly
     */
    public String isA(){
        return "Fly";
    }
    
    /* 
     * 
     * Dreht den Fly in Uhrzeigerrichtung.
     *
     */
    private void turnClockwiseDirection(){
        if(route==3){
            route=0;
        }
        else{
            route++;
        }    
    }
    
    /* 
     * 
     * Dreht den Fly gegen die Uhrzeigerrichtung.
     *
     */
    private void vrsTurnClockwiseDirection(){
        if(route==0){
            route=3;
        }
        else{
            route--;
        }
    }
    
    /**
     *
     * L�sst die Fliege sich erholen.
     *
     */
    
    private void relax(){
        if(endurance<maxEndurance){
            endurance++;
        }
    }
    
    public boolean isPossibleToFly(){
        if(endurance>=30){
            return true;
        }    
        return false;
                    
    }
    
    /**
     * 
     * L�sst die Fliege wegfliegen.
     * 
     * 
     * @param entityHelp
     * @param myMath
     */
    
    public void flyAway(MyMath myMath){
        isFlying=true;
        boolean founded = false;
        {
            int[] position = EntityHelpings.walkableRandomFieldIndex();
            xPosAim=position[0]*(9*faktor)+(4*faktor);
            yPosAim=position[1]*(9*faktor)+(4*faktor);
            int dist = myMath.getDist(xPos,yPos,xPosAim,yPosAim);
            if(dist > 55 ){
                founded = true;
            }
        }while(founded = false);
        endurance=endurance-30;
        if(Math.abs(xPos-xPosAim) >= Math.abs(yPos-yPosAim)){
            if(xPos>xPosAim){
                route=3;
            }else{
                route=1;
            }            
        }else{
            if(yPos>yPosAim){
                route=0;
            }else{
                route=2;
            }
        }
    }
    /**
     *
     * Gibt die aktuelle Ausdauer zur�ck.
     * 
     * @return endurance
     */
    public int getEndurance(){
        return endurance;
    }
    
    /**
     *
     * L�sst dei Fliege rumlaufen.
     *
     * @param rand
     * @param myMath
     * @param field das Spielfeld
     * @param entityhelp 
     */
    public void walking(Random rand,MyMath myMath,Field field){
        relax();
        // die Bewegung beim rumfliegen
        if(isFlying){
            if(field.getTileAbsolutPos(xPosAim,yPosAim).getWakable()==false){
                this.flyAway(myMath);
            }else{
                if(Math.abs(xPos-xPosAim)<(9*faktor) && Math.abs(yPos-yPosAim)<(9*faktor)){
                    xPos=xPosAim;
                    yPos=yPosAim;
                    isFlying=false;
                }else{
                    int dist=Math.abs(xPos-xPosAim)+Math.abs(yPos-yPosAim);
                    if(xPos>xPosAim){
                        xPos-=((15*faktor)*Math.abs(xPos-xPosAim)/dist);
                    }
                    if(yPos>yPosAim){
                        yPos-=((15*faktor)*Math.abs(yPos-yPosAim)/dist);
                    }
                    if(xPos<xPosAim){
                        xPos+=((15*faktor)*Math.abs(xPos-xPosAim)/dist);
                    }
                    if(yPos<yPosAim){
                        yPos+=((15*faktor)*Math.abs(yPos-yPosAim)/dist);
                    }
                }
            }
        }else{
            oneStep(rand,field);
        }   
    }
    
    /**
     * Eine Bewegung des Bug, in deier Methode wird der Laufstatus und die X-Y 
     * Positionsver�nderrung gemacht.
     *
     * @param rand ein Random objekt
     * @param field das Spielfeld
     */
    public void oneStep(Random rand,Field field){    
        think(rand,field);
        if(route==0){
            yPos=yPos-(3*faktor);
        }
        if(route==1){
            xPos=xPos+(3*faktor);
        }
        if(route==2){
            yPos=yPos+(3*faktor);
        }
        if(route==3){
            xPos=xPos-(3*faktor);
        }
    }
    
    /*
     *
     */
    private void think(Random rand,Field field){
        
        // ist auf einer Mittelpunktkreuzung und Random bereich
        if(field.isCenterOfTile(xPos) && field.isCenterOfTile(yPos)){
            int tmp = Math.abs(rand.nextInt()%7);
            if(tmp==1){
                if((yPos-(9*faktor))/(9*faktor) >0){
                    if(field.getTileAbsolutPos(xPos,yPos-(9*faktor)).getWakable()){
                        route=0;
                    }
                }
            }    
            if(tmp==2){
                if((xPos+(9*faktor))/(9*faktor) < field.getIndexX()-1){
                    if(field.getTileAbsolutPos(xPos+(9*faktor),yPos).getWakable()){
                        route=1;
                    }
                }
            }
            if(tmp==3){
                if((yPos+(9*faktor))/(9*faktor) < field.getIndexY()-1){                    
                    if(field.getTileAbsolutPos(xPos,yPos+(9*faktor)).getWakable()){
                        route=2;
                    }
                } 
            }
            if(tmp==4){
                if((xPos-(9*faktor))/(9*faktor) >0){
                    if(field.getTileAbsolutPos(xPos-(9*faktor),yPos).getWakable()){
                        route=3;
                    }
                }  
            }
            borderTest(field);            
        }
        //�berpr�fen ob das n�chste Feld nicht walkable ist
        if(!nextFieldWalkable(field)){
            //umdrehen
            vrsTurnClockwiseDirection();
            vrsTurnClockwiseDirection();
        }
    }
    
    private void borderTest(Field field){
        if(xPos==(4*faktor)){
           route=1;
        }
        if(yPos==(4*faktor)){
            route=2;
        }
        if((field.getIndexX()*(9*faktor))-(5*faktor)==xPos){
            route=3;
        }
        if((field.getIndexY()*(9*faktor))-(5*faktor)==yPos){
            route=0;
        }
    }
    
    /*
     *
     * �berpr�ft ob das n�chste Feld walkable ist.
     *
     */
    private boolean nextFieldWalkable(Field field){
        if(route==0){
           if(field.getTileAbsolutPos(xPos,yPos-stepsize).getWakable()){
               return true;
           }
        }
        if(route==1){
           if(field.getTileAbsolutPos(xPos+stepsize,yPos).getWakable()){
               return true;
           }
        }
        if(route==2){
           if(field.getTileAbsolutPos(xPos,yPos+stepsize).getWakable()){
               return true;
           }
        }
        if(route==3){
           if(field.getTileAbsolutPos(xPos-stepsize,yPos).getWakable()){
               return true;
           }
        }
        return false;
    }
        
   /**
    *
    * Gibt zur�ck ob die Fliege fliegt.
    *
    * @return fliegt?
    */
    public boolean isFlying(){
        return isFlying;
    }
    
}
