/*
 * Leaf.java
 *
 * Created on 7. Februar 2008, 21:49
 *
 * Das Blatt das von einem Tausendf��ler erzeugt wird und von ihm gefressen werden kann.
 */

package entitys;

/**
 * Das Blatt das von einem Tausendf��ler erzeugt wird und von ihm gefressen werden kann.
 *
 * @author Reimar Schr�ter,
 *          Alexander Grebhahn
 */
public class Leaf {
    
    private int xPos;
    private int yPos;
    private int status=0;
    private int faktor=1;
    
    /**
     * Creates a new instance of Leaf.
     *
     * @param xPosI
     * @param yPosI
     */
    public Leaf(int xPosI,int yPosI,int faktor) {
    	this.faktor=faktor;
        xPos=xPosI;
        yPos=yPosI;
    }
    
    /**
     * Gibt die xPos des Blattes zur�ck.
     *
     * @return xPos
     */    
    public int getxPos(){
        return xPos;
    }
    
    /**
     * Gibt die yPos des Blattes zur�ck.
     *
     * @return yPos
     */
    
    public int getyPos(){
        return yPos;
    }
    
    /**
     * 
     * Gibt den gefressen Staturs zur�ck, zu wie weit das Leaf gefressen wurde. Von 0 bis 3.
     * 
     * 
     * @return status
     */
    public int getStatus(){
        return status;
    }
    
    /**
     *
     * Erh�ht den gefressen Status um 1.
     *
     */
    public void incStatus(){
        status++;
    }
    
    /**
     * Gibt die minimum xPosition des Leaf zur�ck.
     * 
     * 
     * @return minimale xPosition
     */
    public int getminxPos(){
        return xPos-(int)(9*faktor)/2;
    }
    
    /**
     * Gibt die minimum yPosition des Leaf zur�ck.
     * 
     * 
     * @return minimale xPosition
     */
    public int getminyPos(){
        return yPos-(int)(9*faktor)/2;
    }
}
