/*
 * MyRms.java
 *
 * Created on 1. April 2008, 21:37
 *
 * Speichert wichtige Informationen des Benutzers in Handy und liest sie aus.
 */

package menu;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;


/**
 * Speichert wichtige Informationen des Benutzers in Handy und liest sie aus.
 *
 * @author  Alexander Grebhahn
 *          Reimar Schr�ter
 */
public class MyRms {
    private String[] tmpAll;
    private String[] tmpHighscore;
    private String[] tmpSettings;
    private String[] tmpMapSettings;
    private boolean mustRenewRead=true;
    
    /** Creates a new instance of MyRms */
    public MyRms() {
    }
    
    /**
     *  Schreibt einen String per RMS.
     *
     *  @param s    String der geschrieben werden soll
     */
    private void writeToRMS(String s){

    }
    
    /**
     *  Liest einen String per RMS.
     *
     *  @param id Indentifikationsnummer unter der der string abgelegt wurde
     */
    private String readFromRMS(){
    	return "fertig";
    }
    
    /**
     *
     * Gitb die gespeicherten Einstellungen des Benutzers zur�ck.
     *
     * @return Einstellungen
     */
    public String[] getSettings(){
        if( mustRenewRead){
            makeTmpStrings();
            mustRenewRead=false;
        }
        return tmpSettings;
    }
    
    
    private void makeTmpStrings(){
        try{
            tmpAll=getSubStrings(readAll());
            
            tmpHighscore=new String[tmpAll.length-5];
            tmpSettings=new String[2];
            tmpMapSettings=new String[3];
        } catch(Exception e){
            
        }
        for(int i=0;i<tmpHighscore.length;i++){
            tmpHighscore[i]=tmpAll[i+5];
        }
        for(int i=0;i<tmpSettings.length;i++){
            tmpSettings[i]=tmpAll[i];
        }
        for(int i=0;i<tmpMapSettings.length;i++){
            tmpMapSettings[i]=tmpAll[i+2];
        }
    }
    
    /**
     *
     * Gitb die gespeicherten Highscores des Benutzers zur�ck.
     *
     * @return Highscores
     */
    
    public String[] getHighscoreStrings(){
        if( mustRenewRead){
            makeTmpStrings();
            mustRenewRead=false;
        }
        return tmpHighscore;
    }
    
    /**
     *
     * Schreibt den Highscore des Benutzers.
     *
     * @param highscore zu schreibender Highscore
     */
    
    public void writeHighscore(String highscore){

    }
    
    /**
     *
     * Gitb die gespeicherten Karteneinstellungen des Benutzers zur�ck.
     *
     * @return Karteneinstellungen
     */
    
    public String[] getMapSettings(){
        if( mustRenewRead){
            makeTmpStrings();
            mustRenewRead=false;
        }
        return tmpMapSettings;
    }
    
    /**
     *
     * Schreibt die Einstellungen des Benutzers.
     *
     * @param setting zu schreibender Einstellungen
     */
    
    public void writeSettings(String setting){

    }
    
    /**
     *
     * Schreibt die Karteneinstellungen des Benutzers.
     *
     * @param settings zu schreibender Karteneinstellungen
     */
    
    public void writeMapSettings(String settings){

    }
    
    
    private String readAll(){

        return "fertig";
    }
    
    private String readStartHighscoreList(){
        String data="";
        try{
            //Auslesen der alten Datei
            InputStream fis = getClass().getResourceAsStream("/menu/highscore.dat");
            int nextChar = -1;
            do {
                nextChar = fis.read();
                if (nextChar != -1) {
                    data +=(char)nextChar;
                }
            } while (nextChar != -1);
            fis.close();
        } catch(Exception e){
            System.err.println("Fehler beim laden der Datei "+e.getMessage());
        }
        return data;
        
    }
    
    
    private String getStringFromSubstrings(String[] strings){
        String tmpString="";
        for(int i=0;i<strings.length;i++){
            if(i!=strings.length-1){
                tmpString+=strings[i]+"\n";
            } else{
                tmpString+=strings[i];
            }
        }
        return tmpString;
    }
    
    private String[] getSubStrings(String readData){
        char[] dataCharArray=readData.toCharArray();
        int count=0;
        for(int i=0;i<dataCharArray.length;i++){
            if(dataCharArray[i]=='\n'){
                count++;
            }
        }
        count++;
        String substring="";
        String[] levelNames=new String[count];
        count=0;
        for(int i=0;i<dataCharArray.length+1;i++){
            if(i==dataCharArray.length || dataCharArray[i]=='\n'){
                levelNames[count]=substring;
                substring="";
                count++;
            } else{
                substring+=dataCharArray[i];
            }
        }
        return levelNames;
    }
    
    
    
}
