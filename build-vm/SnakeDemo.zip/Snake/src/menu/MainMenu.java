/*
 * MainMenu.java
 *
 * Created on 13. Februar 2008, 22:27
 *
 *  Hauptmenue des Spiels, von hier aus werden alle anderen Men�punkte aus des Main aufgerufen.
 */

package menu;


import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;

import javax.swing.JPanel;

import basics.*;
import paint.*;

/**
 * Hauptmen� des Spiels (grafisch).
 *
 * @author  Alexander Grebhahn
 *          Reimar Schr�ter
 */
public class MainMenu extends JPanel implements JPanelListener{
    Image backroundImage=null;
    Field backround=null;
    Painter painter=null;
    String[] menuElements={"Spiel starten","Highscore","Einstellungen","Anleitung","Impressum","Karten","Ende"};
    int centerPosition=0;
    public int selected=0;
    int numberMenuElements=menuElements.length;
    int key=0;
    Main main;
    int xpos=0;
    int ypos=0;
    int width = 0;
    int height = 0;
    boolean fullscreen=true;
    private Field getSizeField;
    
   /**
    *   Konstruktor des Hauptmenues.
    *
    *   @param  main1   �bergibt die Main des Spiels von der alles gesteuert wird
    *   @param  painter1    Painter mit der das Hintergrundbild des Menue gemalt werden kann
    */
    public MainMenu(Main main1,Painter painter1,Field getSizeField) {
        painter=painter1;
        main=main1;
        width = getSizeField.getIndexX() * 9;//((Integer) main.getElementSize().getSelectedItem());
        height = getSizeField.getIndexY() * 9;//((Integer) main.getElementSize().getSelectedItem());
        
        int widthBackroundField  = getSizeField.getIndexX() * getSizeField.getTileSize();
        int heightBackroundField = getSizeField.getIndexY() * getSizeField.getTileSize();
        backround=new Field(widthBackroundField,heightBackroundField,2,2,9,true);
        centerPosition=height/2;

        backroundImage=null;
        this.getSizeField = getSizeField;
    }
    
    /**
     *  Gibt das Hintergrundbild des Menues zur�ck.
     *
     *  @return backroundImage
     */
    public Image getBackround(){
        return backroundImage;
    }
    
    
    /**
     *  Zeichnet den aktuellen Menuestand.
     *
     *  @param  g   Graphics auf der gemalt werden soll
     */
    public void paint(Graphics g){
    	
    	width = getSizeField.getIndexX() * ((Integer) main.getElementSize().getSelectedItem());
        height = getSizeField.getIndexY() * ((Integer) main.getElementSize().getSelectedItem());
        centerPosition=height/2;
        
        g.setColor(Color.BLACK);
        //g.setColor(0,0,0);
        
        g.fillRect(0,0,width,height);
        if(backroundImage==null){
//            backroundImage=painter.paintFrame(backround,null,null);
        }
        g.drawImage(backroundImage,xpos,ypos+20,width,height+20,0,0,getSizeField.getIndexX() * 9 , getSizeField.getIndexY() * 9 ,null);
        
        //g.setColor(220,150,150);
        g.setColor(Color.RED);
        g.drawString(menuElements[(selected+numberMenuElements-1)%numberMenuElements],20,centerPosition-20+10);
        g.drawString(menuElements[(selected+1)%numberMenuElements],20,centerPosition+20+10);
        //g.setColor(196,0,0);
        g.setColor(Color.RED);
        g.drawLine(0,centerPosition-2,width,centerPosition-2);
        g.drawLine(0,centerPosition-3,width,centerPosition-3);
        g.drawLine(0,centerPosition+15,width,centerPosition+15);
        g.drawLine(0,centerPosition+16,width,centerPosition+16);
        g.drawString(menuElements[(selected)%numberMenuElements],20,centerPosition+10);
        main.startGame();
        main.repaint();
    }
    
    /**
     *
     * Behandelt gedr�ckte Tasten.
     *
     * @param keyCode die gedr�ckte Taste
     */
    public void keyPressed(int keyCode) {
    //    key=getGameAction(keyCode);
        if(keyCode==38){//oben 
      //      main.clickMenu();
            selected=(selected+numberMenuElements-1)%numberMenuElements;
            
        }
        if(keyCode==40){//unten
         //   main.clickMenu();
            selected=(selected+1)%numberMenuElements;
        }
        if(keyCode==80||keyCode==10){//best�tigen
            switch (selected){
                case 0: fullscreen=false; main.startGame(); break;
                case 1: main.startHighscore(); break;
                case 2: main.startSettings(); break;
                case 3: main.startInstruction(); break;
                case 4: main.impressum(); break;
                case 5: main.startLevelPath(); break;
                case 6: main.exit(); break;
            }
        }
        repaint();
        
    }
    
}
