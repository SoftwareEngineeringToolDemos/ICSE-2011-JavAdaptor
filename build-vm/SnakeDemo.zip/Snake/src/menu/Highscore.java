/*
 * Highscore.java
 *
 * Created on 17. Februar 2008, 18:06
 *
 *  Diese Klasse verwaltet die Highscore-Werte
 */

package menu;

import menu.MyRms;
import java.io.*;

import basics.Main;


/**
 * Verwaltung der Highscore-Werte.
 *
 * @author  Alexander Grebhahn
 *          Reimar Schr�ter
 */
public class Highscore {
    PointsHighscore[][] points=null;
    MyRms myRms=null;
    
    /** Creates a new instance of Highscore */
    public Highscore(MyRms myRms1) {
        myRms=myRms1;
        
    }
    
    /**
     *  Gibt den minimalen Punktwert zur�ck den man ben�tigt um in die Highscorliste zu kommen.
     *  
     * 
     * @param difficulty in der das Spiel gespielt wurde
     */ 
    public int getPointsMinimal(int difficulty){
        if(points==null){
            loadPoints();
        }
        return points[difficulty][2].getPoints();
    }
    
    
    /**
     *  Gibt die Highscoretabelle der gew�nschten Schwierigkeitsstufe zur�ck.
     *
     *  @param difficulty von der die Highscore angezeigt werden soll
     *  @return Highscoretabelle zu der gew�nschten Schwierigkeit
     *
     */
    public String getHighscoreFromDifficult(int difficulty){
        if(points==null){
            loadPoints();
        }
        return "1.) "+points[difficulty][0].getName()+" "+points[difficulty][0].getPoints()+"\n" +
               "2.) "+points[difficulty][1].getName()+" "+points[difficulty][1].getPoints()+"\n" +
               "3.) "+points[difficulty][2].getName()+" "+points[difficulty][2].getPoints();
    }
    
    
    /**
     *  Setzt den neuen Highscore-Wert.
     * 
     * 
     * @param difficulty in der das Spiel gespielt wurde
     * @param name    Name des Spielers
     * @param newPoints   Punktwert der erreicht wurde
     */
    public void setNewHighscore(int difficulty,String name,int newPoints){
        if(name.length()==0){
            name="Name";
        }
        name.replace('\n','_');
        if(points[difficulty][0].getPoints()<newPoints){
           points[difficulty][2]=points[difficulty][1];
           points[difficulty][1]=points[difficulty][0];
           points[difficulty][0]=new PointsHighscore(name,newPoints);
        }
        else{
            if(points[difficulty][1].getPoints()<newPoints){
                points[difficulty][2]=points[difficulty][1];
                points[difficulty][1]=new PointsHighscore(name,newPoints);
            }
            else{
                if(points[difficulty][2].getPoints()<newPoints){
                    points[difficulty][2]=new PointsHighscore(name,newPoints);
                }
            }
        }
        writeNewHighscore(points);
    }
    
   /**
    *   Liest die Punkte aus dem System aus.
    */ 
    private void loadPoints(){
        points=new PointsHighscore[5][3];
        String[] tmp=myRms.getHighscoreStrings();
        int count=0;
        for(int i=0;i<5;i++){
            for(int m=0;m<3;m++){
                points[i][m]=new PointsHighscore(tmp[count],(int)Integer.parseInt(tmp[count+1]));
                count+=2;
            }
        }
    }
    
    
    /**
     *  Schreibt den neuen Highscore in das System per RMS.
     *
     *  @param high Highscore-Werte die per RMS gespeichert werden sollen
     */
    private void writeNewHighscore(PointsHighscore[][]  high){
        String toWrite="";
        for(int i=0;i<5;i++){
            for(int m=0;m<3;m++){
                toWrite=toWrite+high[i][m].getName()+"\n"+new Integer(high[i][m].getPoints())+"\n";
            }
        }
        try{
            myRms.writeHighscore(toWrite);
        } 
        catch(Exception e){
            Main.sysout("konnte nicht schreiben");
        }
    }
    
}