/*
 * SnakePart.java
 *
 * Created on 20. Dezember 2007, 17:57
 *
 * Mit Hilfe dieser Klasse werden die Einzelnen Teile einer Snake bereitgestellt.
 */

package entitys;

import basics.Main;

/**
 * Einzelne Elemente einer Schlange.
 *
 * @author Reimar Schroeter,Alexander Grebhahn
 */

public class SnakePart {

    /* der Typ des Schlangenteils: head steht f�r den Kopf der Schlange, middle f�r einen mittleren Abschnitt und tale f�r den Schwanz der Schlange*/
    private String typ;
    /* die XPosition des Schlangenteils */
    private int xPos;
    /* die yPosition des Schlangenteils */
    private int yPos;
    /* gibt das Teil zur�ck das sich nach diesem Teil befindet*/
    private SnakePart next=null;
    /* gibt das Teil zur�ck das sich vor diesem Teil befindet*/ 
    private SnakePart prev=null;
    
    /* gibt die Richtung wieder wobei die Zahl modulo 4 gerehnet wird
     *  0 = Norden, 1 = Osten, 2 = S�den und 3 = Westen */
    private int route=-1;
    //ist 11
    private int partsize;
    
    /** 
     * 
     * Konstruktor eines neuen SnakePart.
     *
     * @param typI der Typ der SnakeParts 
     * @param xPosI X-Position des Elementes
     * @param yPosI Y-Position des Elementes 
     * @param partsizeI die Ausma�e des SnakeParts wobei er als Quadrat fungiert
     *
     */
    public SnakePart(String typI,int xPosI,int yPosI,int partsizeI) {
    	Main.sysout("partsize von Snake"+partsizeI);
        typ=typI;
        xPos=xPosI;
        yPos=yPosI;
        partsize=partsizeI;
    }
    
    /**
     * 
     * Gibt die Partsize zur�ck.
     *
     * @return partsize 
     */
    public int getPartsize(){
        return partsize;
    }
    
    /**
     * 
     * Gibt den Typ des SnakePart zur�ck. 
     *
     * @return typ als String
     */
    public String getTyp(){
        return typ;
    }
    
    /**
     * 
     * Setzt die xPos des SnakePart. 
     * 
     * 
     * @param xPosI
     */
    public void setxPos(int xPosI){
        xPos=xPosI;
    }
    
    /** 
     * 
     * Gibt die xPos des SnakePart.
     *
     * @return xPos 
     */
    public int getxPos(){
        return xPos;
    }
    
    /** 
     * 
     * Gibt der linken Rand des SnakePart zur�ck.
     *
     * @return minimum xPos
     */
    public int getminxPos(){
        return xPos-(int)partsize/2;
    }
    
    /** 
     * 
     * Gibt den oberen Rand des SnakePart zur�ck.
     *
     * @return minimum yPos
     */
    public int getminyPos(){
        return yPos-(int)partsize/2;
    }
    
    /**
     * 
     * 
     * Ver�ndert die yPos des SnakeParts.
     * 
     * 
     * @param yPosI neue Y-Position des SnakePart
     */
    public void setyPos(int yPosI){
        yPos=yPosI;
    }
    
    /** 
     * 
     * Gibt die yPos des SnakePart zur�ck.
     *
     * @return yPos
     */
    public int getyPos(){
        return yPos;
    }
    
    /**
     * 
     * Verkn�pft dieses Element mit dem n�chsten in der Schlange, 
     * wobei das N�chste auch mit diesem als Vorg�nger Verkn�pft wird.
     * 
     * 
     * @param nextElement
     */
    public void setNext(SnakePart nextElement){
        next=nextElement;
        nextElement.setPrev(this);
    }
    
    /**
     * 
     * Gibt das N�chsten Element in der Snake zur�ck.
     *
     * @return das n�chste Element
     *
     */
    public SnakePart getNext(){
        return this.next;
    }
    
    /*
     * 
     * Verkn�pfung diese Element mit seinem Vorg�nger.
     *
     * @param prevElement
     */
    private void setPrev(SnakePart prevElement){
        prev=prevElement;
    }
    
    /**
     * 
     * Gibt vorherige Elemente der Snake zur�ck.
     *
     * @return prev
     */
    public SnakePart getPrev(){
        return this.prev;
    }
    
    /**
     * 
     * Ver�ndert die Richtung des SnakePart.
     * 
     * 
     * @param newRoute
     */
    public void setRoute(int newRoute){
        route= newRoute;
    }
    
    /** 
     * 
     * Gibt die Richtung des Teils zur�ck.
     *
     * @return route
     */
    public int getRouteInt(){
        return route;
    }
    
    /** 
     * 
     * Gibt die Richtung des Teils zur�ck.
     *
     * @return route als String
     */
    public String getRouteString(){
        if(route % 4==0){
            return "Norden";
        }
        if(route % 4==1){
            return "Osten";
        }
        if(route % 4==2){
            return "S�den";
        }
        if(route % 4==3){
            return "Westen";
        }
        return "schwerer Ausnahmfehler der nie eisetzen d�rfte";
    }
    
}
