/*
 * SlugPart.java
 *
 * Created on 17. Januar 2008, 16:13
 *
 * SlugPart
 */

package entitys;

/**
 * Elemente einer Schnecke.
 *
 * @author Reimar Schr�ter, Alexander Grebhahn
 */
public class SlugPart {
    
    int xPos;
    int yPos;
    private String typ;
    private int partsize=11;
    private SlugPart next=null;
    private int route;
    private int age=0;
    private int faktor=1;
    
    /** 
     * Erschaft einen neuen SlugPart. 
     *
     *
     * @param typI der Typ des SlugParts entweder slime oder slug
     * @param xPosI X-Position
     * @param yPosI Y-Position
     *
     */
    public SlugPart(String typI,int xPosI,int yPosI,int faktor) {
    	this.faktor=faktor;
    	partsize=partsize*faktor;
      typ=typI;
      xPos=xPosI;
      yPos=yPosI;
    }
    
    /**
     *
     * Gibt die xPos des SlugPart zur�ck.
     *
     * @return xPos
     */
    public int getxPos(){
        return xPos;
    }
    
    /**
     *
     * Gibt die yPos des SlugPart zur�ck.
     *
     * @return yPos
     */
    public int getyPos(){
        return yPos;
    }
    
    /**
     *
     * Setzt die neue X-Position des SlugPart.
     *
     * @param xPosI
     *
     */
    public void setxPos(int xPosI){
        xPos=xPosI;
    }
    
    /**
     *
     * Setzt die neue Y-Position des SlugPart.
     *
     * @param yPosI
     */
    public void setyPos(int yPosI){
        yPos=yPosI;
    }  
    
    /** 
     * 
     * Gibt der linken Rand des SlugPart zur�ck.
     *
     * @return minimum xPos
     */
    public int getminxPos(){
        return xPos-(int)partsize/2;
    }
    
    /** 
     * 
     * Gibt den oberen Rand des SlugPart zur�ck.
     *
     * @return minimum yPos
     */
    public int getminyPos(){
        return yPos-(int)partsize/2;
    }
    
    /**
     *
     * Gibt das N�chste Element zur�ck.
     *
     * @return das n�chste Element
     *
     */
    public SlugPart getNext(){
        return next;
    }
    
    /**
     *
     * Setzt das N�chste Elmenet(nextI).
     *
     * @param nextI
     */
    public void setNext(SlugPart nextI){
        next=nextI;
    }
    
    /**
     *
     * Gibt die Richtung des SlugPart zur�ck.
     *
     * @return route
     *
     */
    public int getRoute(){
        return route;
    }
    
    /**
     * 
     * Setzt die neue Richtung des SlugPart.
     * 
     * 
     * @param newRoute
     */
    public void setRoute(int newRoute){
        route=newRoute;
    }
    
    /**
     *
     * gibt die Anzahl der Frames zur�ck die der SlugPart schon existiert.
     *
     * @return age
     */
    public int getAge(){
        return age;
    }
    
    /**
     *
     * Erh�ht das Alter um 1.
     */
    public void incAge(){
        age++;
    }
}

