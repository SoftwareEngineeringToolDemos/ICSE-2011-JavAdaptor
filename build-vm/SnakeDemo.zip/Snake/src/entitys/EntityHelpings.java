/*
 * EntityHelpings.java
 *
 * Created on 17. Februar 2008, 11:14
 *
 * Diese Klasse stellt hlfreiche Methoden f�r die Entitys zur Verf�gung
 */

package entitys;

import basics.Field;
import basics.GameField;
import basics.MyMath;
import basics.QueueElement;
import java.util.Random;

public class EntityHelpings {
    
    private static Field field;
    private static Random rand;
    protected static int factor=1;
    
    public EntityHelpings(Field fieldI,Random randI,int factorI) {
    	factor=factorI;
        field=fieldI;
        rand=randI;
    }
    
    
    public static int[] walkableRandomFieldIndex(){
        int[]back = new int[2];
        back[0]=Math.abs(rand.nextInt()%(field.getIndexX()-1));
        back[1]=Math.abs(rand.nextInt()%(field.getIndexY()-1));
        if(!field.getWalkableAbsolutPos(back[0]*(9*factor),back[1]*(9*factor))){
            back=walkableRandomFieldIndex();
        }
        return back;
    }
    
    public QueueElement MousePos(int route){
        int[] position = walkableRandomFieldIndex();
        if(route==0){
            if(position[1]<field.getIndexY()-2){
                if(field.getWalkableAbsolutPos((position[0])*(9*factor),(position[1])*(9*factor)) && field.getWalkableAbsolutPos((position[0])*(9*factor),(position[1]+1)*(9*factor))){
                   return new QueueElement(position[0],position[1]);
                }
            }
        }
        if(route==1){
            if(position[0]>=1){
                if(field.getWalkableAbsolutPos((position[0])*(9*factor),(position[1])*(9*factor)) && field.getWalkableAbsolutPos((position[0]-1)*(9*factor),(position[1])*(9*factor))){
                    return new QueueElement(position[0],position[1]);
                }
            }   
        }
        if(route==2){
            if(position[1]>=1){
                if(field.getWalkableAbsolutPos((position[0])*(9*factor),(position[1])*(9*factor)) && field.getWalkableAbsolutPos((position[0])*(9*factor),(position[1]-1)*(9*factor))){
                    return new QueueElement(position[0],position[1]);
                }
            }
        }
        if(route==3){
            if(position[0]<field.getIndexX()-2){
                if(field.getWalkableAbsolutPos((position[0])*(9*factor),(position[1])*(9*factor)) && field.getWalkableAbsolutPos((position[0]+1)*(9*factor),(position[1])*(9*factor))){
                    return new QueueElement(position[0],position[1]);
                }
            }
        }    
        return MousePos(route);
    }
 
    public QueueElement CentipedePos(int route,int rek){
        if(rek==20){
            return null;
        }
        int[] position = walkableRandomFieldIndexCenti(route);
        if(route==0){
            if(position[1]<field.getIndexY()-5){
                if(field.getWalkableAbsolutPos((position[0])*(9*factor),(position[1])*(9*factor)) && field.getWalkableAbsolutPos((position[0])*(9*factor),(position[1]+1)*(9*factor))){
                    if(field.getWalkableAbsolutPos((position[0])*(9*factor),(position[1]+2)*(9*factor)) && field.getWalkableAbsolutPos((position[0])*(9*factor),(position[1]+3)*(9*factor))){
                        if(field.getWalkableAbsolutPos((position[0])*(9*factor),(position[1]+4)*(9*factor))){
                            return new QueueElement(position[0],position[1]);
                        }
                    }
                }    
            }
        }
        if(route==1){
            if(position[0]>=4){
                if(field.getWalkableAbsolutPos((position[0])*(9*factor),(position[1])*(9*factor)) && field.getWalkableAbsolutPos((position[0]-1)*(9*factor),(position[1])*(9*factor))){
                    if(field.getWalkableAbsolutPos((position[0]-2)*(9*factor),(position[1])*(9*factor)) && field.getWalkableAbsolutPos((position[0]-3)*(9*factor),(position[1])*(9*factor))){
                        if(field.getWalkableAbsolutPos((position[0]-4)*(9*factor),(position[1])*(9*factor))){
                            return new QueueElement(position[0],position[1]);
                        }
                    }
                }    
            }
        }
        if(route==2){
            if(position[1]>=4){
                if(field.getWalkableAbsolutPos((position[0])*(9*factor),(position[1])*(9*factor)) && field.getWalkableAbsolutPos((position[0])*(9*factor),(position[1]-1)*(9*factor))){
                    if(field.getWalkableAbsolutPos((position[0])*(9*factor),(position[1]-2)*(9*factor)) && field.getWalkableAbsolutPos((position[0])*(9*factor),(position[1]-3)*(9*factor))){
                        if(field.getWalkableAbsolutPos((position[0])*(9*factor),(position[1]-4)*(9*factor))){
                            return new QueueElement(position[0],position[1]);
                        }
                    }
                }    
            }
        }
        if(route==3){
            if(position[0]<field.getIndexX()-5){
                if(field.getWalkableAbsolutPos((position[0])*(9*factor),(position[1])*(9*factor)) && field.getWalkableAbsolutPos((position[0]+1)*(9*factor),(position[1])*(9*factor))){
                    if(field.getWalkableAbsolutPos((position[0]+2)*(9*factor),(position[1])*(9*factor)) && field.getWalkableAbsolutPos((position[0]+3)*(9*factor),(position[1])*(9*factor))){
                        if(field.getWalkableAbsolutPos((position[0]+4)*(9*factor),(position[1])*(9*factor))){
                            return new QueueElement(position[0],position[1]);
                        }
                    }
                }    
            }
        }                
        return CentipedePos(route,rek+1);
    }
    
    public static int[] walkableRandomFieldIndexCenti(int route){
        int[]back = new int[2];
        if(route==0){
            back[0]=Math.abs(rand.nextInt()%(field.getIndexX()-1));
            back[1]=Math.abs(rand.nextInt()%(field.getIndexY()-5));
            if(!field.getWalkableAbsolutPos(back[0]*(9*factor),back[1]*(9*factor))){
                back=walkableRandomFieldIndexCenti(route);
            }
        }
        if(route==1){
            back[0]=4+Math.abs(rand.nextInt()%(field.getIndexX()-5));
            back[1]=Math.abs(rand.nextInt()%(field.getIndexY()-1));
            if(!field.getWalkableAbsolutPos(back[0]*(9*factor),back[1]*(9*factor))){
                back=walkableRandomFieldIndexCenti(route);
            }
        }
        if(route==2){
            back[0]=Math.abs(rand.nextInt()%(field.getIndexX()-1));
            back[1]=4+Math.abs(rand.nextInt()%(field.getIndexY()-5));
            if(!field.getWalkableAbsolutPos(back[0]*(9*factor),back[1]*(9*factor))){
                back=walkableRandomFieldIndexCenti(route);
            }
        }
        if(route==3){
            back[0]=Math.abs(rand.nextInt()%(field.getIndexX()-5));
            back[1]=Math.abs(rand.nextInt()%(field.getIndexY()-1));
            if(!field.getWalkableAbsolutPos(back[0]*(9*factor),back[1]*(9*factor))){
                back=walkableRandomFieldIndexCenti(route);
            }
        }
        return back;
    }
    
    
    // TODO update2 eatableEntity : comment the next line
    /*
    public static Bug newBug(Random rand,int factor,Field field,Snake snake, boolean[][] fieldwithoutEntitys){
        int route =Math.abs(rand.nextInt()%4);
        EntityHelpings entityhelp = new EntityHelpings(field, rand, factor);
        
        int abs;
        int[] position;
        
        do{
            position = entityhelp.walkableRandomFieldIndex();
            abs = MyMath.getDist(snake.getxPos(),snake.getyPos(),position[0]*(9*factor),position[1]*(9*factor));   
            
        }while(abs<27);
        
        Bug bug = new Bug((position[0]*(9*factor))+(4*factor),(position[1]*(9*factor))+(4*factor),route,factor);
        return bug;
    }
    //*/



}
