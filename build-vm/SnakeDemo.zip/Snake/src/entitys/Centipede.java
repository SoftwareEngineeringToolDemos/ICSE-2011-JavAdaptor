/*
 * Centipede.java
 *
 * Created on 25. Januar 2008, 13:35
 *
 * Centi der Centipede
 */

package entitys;

import basics.Field;
import basics.QueueElement;
import basics.Queue;
import basics.MyMath;
import java.util.Random;

/**
 * Verwirklichung eines Tausendf��lers.
 *
 * @author Reimar Schr�ter, Alexander Grebhahn
 */

public class Centipede extends Entity{
   
    private CentiPart[] entity;
    private int status=0;
    private int leafsEaten=-1;
    private boolean alive=true;
    private Leaf leaf;
    private Random rand;
    private MyMath myMath;
    private int[][] fieldValuation;
    private boolean[][] fieldValuated;
    private boolean[][] fieldWalkableWithoutSnake;
    private int faktor=1;
    
    /**
     * Creates a new instance of Centipede.
     *
     * @param xPos die X Position
     * @param yPos die Y Position
     * @param route die Route des Centipede
     * @param field das Spielfeld
     * @param fieldWalkableWithoutSnakeI
     */
    public Centipede(int xPos,int yPos,int route,Field field,boolean[][] fieldWalkableWithoutSnakeI,int faktor) {
    	this.faktor=faktor;
        entity =  new CentiPart[5];
        rand = new Random();
        myMath= new MyMath();
        fieldWalkableWithoutSnake=fieldWalkableWithoutSnakeI;
        fieldValuation= new int[field.getIndexX()][field.getIndexY()];
        fieldValuated= new boolean[field.getIndexX()][field.getIndexY()];
        newLeaf(field);
        fieldValuate(fieldWalkableWithoutSnakeI);
        for(int i=0;i<entity.length;i++){
            CentiPart tmp = new CentiPart(route,xPos,yPos,faktor);
            entity[i]=tmp;
            if(route==0){
                yPos+=(9*faktor);
            }
            if(route==1){
                xPos-=(9*faktor);
            }
            if(route==2){
                yPos-=(9*faktor);
            }
            if(route==3){
                xPos+=(9*faktor);
            }
        }                
        //feldBewertungausgeben();
    }
    
    /**
     *
     * Gibt zur�ck ob der Tausendf��ler lebt.
     *
     * @return lebt er?
     */
    public boolean isAlive(){
        return alive;
    }    
    
    /**
     * Gibt den Zeichenstatus wieder.
     *
     * @return satus?
     */
    public int getStatus(){
        return status;
    }
    
    /**
     * Gibt die L�nge des Tausendf��lers zur�ck.
     *
     * @return 5
     */
    public int getLength(){
        return entity.length;
    }
    
    /**
     * Gibt den Part an der i-ten Stelle zur�ck
     * 
     * 
     * @return CentiPart an der Selle index
     */
    public CentiPart getPart(int index){
        return entity[index];
    }
    
    /**
     * Simmuliert eine Bewegung.
     *
     * @param field das SpielFeld
     */
    public void oneStep(Field field){
        int distanceTileStraight=Integer.MAX_VALUE;
        int distanceTileLeft=Integer.MAX_VALUE;
        int distanceTileRight=Integer.MAX_VALUE;
        boolean alreadyTurned=false;
        
        int xIndex= this.getPart(0).getxPos()/(9*faktor);
        int yIndex= this.getPart(0).getyPos()/(9*faktor);        
        
        int distLeaf= MyMath.getDist(this.getPart(0).getxPos(),this.getPart(0).getyPos(),this.getLeaf().getxPos(),this.getLeaf().getyPos());
        if(alive){
            status++;
            //Leaf essen
            if(distLeaf==(9*faktor)){
                eatLeaf(field);                
            }else{
            //zum Leaf bewegen
            
                // abst�nde Festlegen                
                distanceTileStraight=distNextFieldToLeaf(this.getPart(0).getRoute(),xIndex,yIndex,field);
                distanceTileLeft=distNextFieldToLeaf(this.getPart(0).getRoute()-1,xIndex,yIndex,field);
                distanceTileRight=distNextFieldToLeaf(this.getPart(0).getRoute()+1,xIndex,yIndex,field);
                
                if(distanceTileLeft<=distanceTileStraight && distanceTileLeft<=distanceTileRight){
                    this.vrsTurnClockwiseDirection();
                    alreadyTurned=true;
                }
                if(distanceTileRight<=distanceTileStraight && distanceTileRight<=distanceTileLeft){
                    if(!alreadyTurned){                        
                        this.turnClockwiseDirection();
                    }
                }
                if(distanceTileStraight==Integer.MAX_VALUE && distanceTileLeft==Integer.MAX_VALUE && distanceTileRight==Integer.MAX_VALUE){
                    this.turnClockwiseDirection();
                }else{
                    changePosition();
                }
            }
        }else{
            //Verwesung
            for(int i=0;i<this.getLength();i++){
                if(!this.getPart(i).isAlive()){
                    this.getPart(i).incRot();
                }
            }
        }
    }
    
    private int distNextFieldToLeaf(int route,int xIndex,int yIndex,Field field){
        //wieder route anpassen 
        if(route==4){route=0;}
        if(route==-1){route=3;}
        
        if((route==0 && yIndex==0) || (route==1 && xIndex==fieldValuated.length) || (route==2 && yIndex==fieldValuated[0].length) || (route==3 && xIndex==0)) {
            return Integer.MAX_VALUE;
        }
        if(route==0){
            if(field.getWalkableAbsolutPos((xIndex)*(9*faktor),(yIndex-1)*(9*faktor))){
                return fieldValuation[xIndex][yIndex-1];
            }
        }
        if(route==1){
            if(field.getWalkableAbsolutPos((xIndex+1)*(9*faktor),(yIndex)*(9*faktor))){
                return fieldValuation[xIndex+1][yIndex];
            }
        }
        if(route==2){
            if(field.getWalkableAbsolutPos((xIndex)*(9*faktor),(yIndex+1)*(9*faktor))){
                return fieldValuation[xIndex][yIndex+1];
            }
        }
        if(route==3){
            if(field.getWalkableAbsolutPos((xIndex-1)*(9*faktor),(yIndex)*(9*faktor))){
                return fieldValuation[xIndex-1][yIndex];
            }
        }
        
        return Integer.MAX_VALUE;
    }
    
    
    private void eatLeaf(Field field){
        //Leaf essen
        this.getLeaf().incStatus();
        if(this.getLeaf().getStatus()>3){
            newLeaf(field);
            fieldValuate(fieldWalkableWithoutSnake);
            //feldBewertungausgeben();
        }
    }
    /**
     *
     * Gibt zur�ck ob der Tausendf��ler vollkommen gegessen wurde.
     * 
     * @return komplett gegessen
     */
    public boolean isFullEaten(){
        return (!(entity[0].isAlive() || entity[1].isAlive() || entity[2].isAlive()|| entity[3].isAlive()|| entity[4].isAlive()));        
    }
    
    
    
    
    private void changePosition(){
        for(int i=entity.length-1;i>=1;i--){
            entity[i].setxPos(entity[i-1].getxPos());
            entity[i].setyPos(entity[i-1].getyPos());
            entity[i].setRoute(entity[i-1].getRoute());
        }
        if(entity[0].getRoute()==0){
            entity[0].setyPos(entity[0].getyPos()-(9*faktor));
        }
        if(entity[0].getRoute()==1){
            entity[0].setxPos(entity[0].getxPos()+(9*faktor));
        }
        if(entity[0].getRoute()==2){
            entity[0].setyPos(entity[0].getyPos()+(9*faktor));
        }
        if(entity[0].getRoute()==3){
            entity[0].setxPos(entity[0].getxPos()-(9*faktor));
        }
    }    
    
    /* 
     * 
     * Dreht den Tausendf��lerkopf in Uhrzeigerrichtung.
     *
     */
    private void turnClockwiseDirection(){
        if(entity[0].getRoute()==3){
            entity[0].setRoute(0);
        } else{
            entity[0].setRoute(entity[0].getRoute()+1);
        }
    }
    
    /*
     *
     * Dreht den Tausendf��lerkopf gegen die Uhrzeigerrichtung.
     *
     */
    private void vrsTurnClockwiseDirection(){
        if(entity[0].getRoute()==0){
            entity[0].setRoute(3);
        } else{
            entity[0].setRoute(entity[0].getRoute()-1);
        }
    }
    
    /**
     *
     * Bringt den Tausendf��ler um.
     *
     */
    public void kill(){
        alive=false;
    }
    
    /**
     * 
     * Gibt "Centipede" zur�ck um den Tausendf��ler als solchen zu identifizeiren.
     * 
     * 
     * @return Centipede
     */
    public String isA(){
        return "Centipede";
    }
    
    /*
     * 
     * Erzeugt ein neues Leaf.
     *
     */
    private void newLeaf(Field field){
        int[] position = walkableRandomFieldIndex(field);
        leafsEaten++;
        leaf = new Leaf(position[0]*(9*faktor)+(4*faktor),position[1]*(9*faktor)+(4*faktor),faktor);
    }
    
    public int getFaktor(){
    	return faktor;
    }
    
    /*
     *
     * Gibt ein Zufallsfeld was begehbar ist in eime Field zur�ch xPos,yPos.
     *  
     * @param field das Spielfeld
     * @return xPos , yPos
     */
    private int[] walkableRandomFieldIndex(Field field){
        int[]back = new int[2];
        back[0]=Math.abs(rand.nextInt()%(field.getIndexX()-1));
        back[1]=Math.abs(rand.nextInt()%(field.getIndexY()-1));
        if(!field.getWalkableAbsolutPos(back[0]*(9*faktor),back[1]*(9*faktor))){            
            back=walkableRandomFieldIndex(field);
        }
        return back;         
    }
    
    /**
     * 
     * Gibt das Leaf zur�ck.
     * 
     * 
     * @return Leaf
     */
    public Leaf getLeaf(){
        return leaf;
    }

    private void fieldValuate(boolean[][] fieldWithoutEntity) {
        boolean wayFounded=false;
        boolean start= true;
        //alle Entfernungen werden auf Maximal gesetzt
        //und alle Felder unbewertet
        for(int i=0;i<fieldValuation.length;i++){
            for(int j=0;j<fieldValuation[0].length;j++){
                fieldValuation[i][j]=Integer.MAX_VALUE;
                fieldValuated[i][j]=false;
            }
        }
        
        Queue queue = new Queue();
        queue.addLast(new QueueElement(leaf.getxPos()/(9*faktor),leaf.getyPos()/(9*faktor)));
        fieldValuated[leaf.getxPos()/(9*faktor)][leaf.getyPos()/(9*faktor)]= true;
        while(!queue.isEmpty() || wayFounded){
            QueueElement head = queue.getAndRemoveFirst();
            //entfernung festlegen
            if(start){
                start=false;
                fieldValuation[head.getxIndex()][head.getyIndex()]=0;
            }else{
                fieldValuation[head.getxIndex()][head.getyIndex()]=minOfSourrounding(head,fieldWithoutEntity)+(9*faktor);
            }    
            
           //Umgebungsfelder in Queue anh�ngen
            //Feld links vom Start
            if(head.getxIndex()>0){
                if(fieldValuated[head.getxIndex()-1][head.getyIndex()]==false && fieldWithoutEntity[head.getxIndex()-1][head.getyIndex()]== true){
                    queue.addLast(new QueueElement(head.getxIndex()-1,head.getyIndex()));
                    fieldValuated[head.getxIndex()-1][head.getyIndex()]=true;
                }
            }
            //Feld oberhalb des Start
            if(head.getyIndex()>0){
                if(fieldValuated[head.getxIndex()][head.getyIndex()-1]==false && fieldWithoutEntity[(head.getxIndex())][head.getyIndex()-1]== true){
                    queue.addLast(new QueueElement(head.getxIndex(),head.getyIndex()-1));
                    fieldValuated[head.getxIndex()][head.getyIndex()-1]=true;
                }
            }
            //Feld rechts vom Start
            if(head.getxIndex()<fieldWithoutEntity.length-1){
                if(fieldValuated[head.getxIndex()+1][head.getyIndex()]==false && fieldWithoutEntity[(head.getxIndex()+1)][(head.getyIndex())]== true){
                    queue.addLast(new QueueElement(head.getxIndex()+1,head.getyIndex()));
                    fieldValuated[head.getxIndex()+1][head.getyIndex()]=true;
                }
            }
            //Feld unterhalb des Strat
            if(head.getyIndex()<fieldWithoutEntity[0].length-1){
                if(fieldValuated[head.getxIndex()][head.getyIndex()+1]==false && fieldWithoutEntity[(head.getxIndex())][(head.getyIndex()+1)]== true){
                    queue.addLast(new QueueElement(head.getxIndex(),head.getyIndex()+1));
                    fieldValuated[head.getxIndex()][head.getyIndex()+1]=true;
                }
            }

        }
    }
    
    /*
     * Gibt das minimum der Bewertungen in der Umgebung des Elementes zur�ck.Es k�nnen auch Elemente am rand eingegeben werden.
     *
     * @param QueueElement, 
     * @param field 
     * @return minimum der Umgebung 
     *
     */
    private int minOfSourrounding(QueueElement element,boolean[][] field){
        //Element oben,links
        if(element.getxIndex()==0 && element.getyIndex()==0){
            return Math.min(fieldValuation[0][1],fieldValuation[1][0]);
        }
        //Element unten,links
        if(element.getxIndex()==0 && element.getyIndex()==field[0].length-1){
            return Math.min(fieldValuation[0][field[0].length-2],fieldValuation[1][field[0].length-1]);
        }
        //Element unten,rechts
        if(element.getxIndex()==field.length-1 && element.getyIndex()==field[0].length-1){
            return Math.min(fieldValuation[field.length-1][field[0].length-2],fieldValuation[field.length-2][field[0].length-1]);
        }
        //Element oben,rechts
        if(element.getxIndex()==field.length-1 && element.getyIndex()==0){
            return Math.min(fieldValuation[field.length-1][1], fieldValuation[field.length-2][0]);
        }
        //links Rand
        if(element.getxIndex()==0){
            int hilf= Math.min(fieldValuation[0][element.getyIndex()+1],fieldValuation[0][element.getyIndex()-1]);
            return Math.min(hilf,fieldValuation[1][element.getyIndex()]);
        }
        //oben Rand
        if(element.getyIndex()==0){
            int hilf= Math.min(fieldValuation[element.getxIndex()+1][0],fieldValuation[element.getxIndex()-1][0]);
            return Math.min(hilf,fieldValuation[element.getxIndex()][1]);
        }
        //rechts Rand
        if(element.getxIndex()==field.length-1){
            int hilf = Math.min(fieldValuation[element.getxIndex()][element.getyIndex()-1],fieldValuation[element.getxIndex()][element.getyIndex()+1]);
            return Math.min(hilf,fieldValuation[element.getxIndex()-1][element.getyIndex()]);
        }
        //unten Rand
        if(element.getyIndex()==field[0].length-1){
            int hilf = Math.min(fieldValuation[element.getxIndex()-1][element.getyIndex()],fieldValuation[element.getxIndex()+1][element.getyIndex()]);
            return Math.min(hilf,fieldValuation[element.getxIndex()][element.getyIndex()-1]);
        }
        // Element nicht am Rand vom Feld
        return Math.min(Math.min(fieldValuation[element.getxIndex()-1][element.getyIndex()],fieldValuation[element.getxIndex()+1][element.getyIndex()]),Math.min(fieldValuation[element.getxIndex()][element.getyIndex()-1],fieldValuation[element.getxIndex()][element.getyIndex()+1]));        
    }
    
    /**
     *
     * Gibt die Anzahl der Gefressenen Bl�tter zur�ck.
     *
     * @return int
     */
    public int numberEatenSheets(){
        return leafsEaten;
    }
    
    /**
     * 
     * Gibt die prozentuale Verwesung zur�ck.
     *
     * @return die Aktuelle Verwesungsvortschritt
     */
    public int maxRot(){
        return Math.max(this.getPart(4).getRot(),Math.max(Math.max(this.getPart(0).getRot(),this.getPart(1).getRot()),Math.max(this.getPart(2).getRot(),this.getPart(3).getRot())));
    }
}
