/*
 * MyMath.java
 *
 * Created on 24. Januar 2008, 16:16
 *
 * Einfache kleine mathematische Methoden.
 */

package basics;


/**
 * Einfache kleine mathematische Methoden.
 *
 * @author  Alexander Grebhahn
 *          Reimar Schr�ter
 */
public class MyMath {
    
    /** Creates a new instance of MyMath */
    public MyMath() {
    }
    
    /**
     *  Gibt die Distance von 2 Entitys wieder.
     * 
     * @param xEntityI  x-Koordinate des ersten Entitys
     * @param yEntityI  y-Koordinate des ersten Entitys
     * @param xEntityII x-Koordinate des zweiten Entitys
     * @param yEntityII y-Koordinate des zweiten Entitys
     * @return Distanz zwischen den Entitys
     * 
     */
    public static int getDist(int xEntityI,int yEntityI,int xEntityII,int yEntityII){
            double sqrt=Math.sqrt((xEntityI-xEntityII)*(xEntityI-xEntityII)+(yEntityI-yEntityII)*(yEntityI-yEntityII));
        return (int)sqrt;
    }
    
    /**
     *  Gibt die Richtung+1 an in der der Abstand zu einem Entity maximal ist.
     *  
     *  @param  para1 Abstand 1 zwischen zwei Entitys  
     *  @param  para2 Abstand 2 zwischen zwei Entitys
     *  @param  para3 Abstand 3 zwischen zwei Entitys
     *  @param  para4 Abstand 4 zwischen zwei Entitys
     *  @return Richgtung+1 mit maximalen Abstand
     */
    public int maximumDistance(int para1,int para2,int para3,int para4){
        if(para1>para2 && para1>=para3 && para1>para4){
            return 1;
        }
        if(para2>para1 && para2>para3 && para2>=para4){
            return 2;
        }
        if(para3>para2 && para3>=para1 && para3>para4){
            return 3;
        }
        if(para4>=para2 && para4>para3 && para4>para1){
            return 4;
        }
        return 5;
    }
    
    
    /**
     * Gibt zur�ck ob zwischen den beiden FeldPunkten ein weg der maximal eine Voregegeben l�nge hat existiert.
     *
     * @param field das WalkableFeld auf dem sich die Punkte befinden 
     * @param xPosI die X-Position des ersten FeldPunktes
     * @param yPosI die Y-Position des ersten FeldPunktes
     * @param xPosII die X-Position des zweiten FeldPunktes
     * @param yPosII die Y-Position des zweiten FeldPunktes 
     * @param maximumDistance die Maiximale l�nge des Weges(als PunkteIndex)
     *
     * @return ob die Entitys in der vorgegeben Distanz zu einander liegen
     */
    public boolean checkedDistance(boolean[][] field,int xPosI,int yPosI,int xPosII, int yPosII, int maximumDistance) {
        boolean foundWay=false;
        boolean start= true;
        boolean tmp[][] = new boolean[field.length][field[0].length];
        
        //alle Entfernungen werden auf Maximal gesetzt
        //und alle Felder unbewertet
        for(int i=0;i<tmp.length;i++){
            for(int j=0;j<tmp[0].length;j++){
                tmp[i][j]=false;
            }
        }
        
        Queue queue = new Queue();
        queue.addLast(new QueueElement(xPosI,yPosI,0));
        tmp[xPosI][yPosI]= true;
        while(!queue.isEmpty()){// || foundWay){
            QueueElement head = queue.getAndRemoveFirst();
            
            //ist das Feld das gesuchte?
            if(head.getxIndex()==xPosII && head.getyIndex()==yPosII){
                return true;
            }
            
            //Umgebungsfelder in Queue anh�ngen wenn sie nicht zuweit entfernt sind
            if(head.getRekRequest()<=maximumDistance){
                //Feld links vom Start
                if(head.getxIndex()>0){
                    if(tmp[head.getxIndex()-1][head.getyIndex()]==false && field[head.getxIndex()-1][head.getyIndex()]== true){
                        queue.addLast(new QueueElement(head.getxIndex()-1,head.getyIndex(),head.getRekRequest()+1));
                        tmp[head.getxIndex()-1][head.getyIndex()]=true;
                    }
                }
                //Feld oberhalb des Start
                if(head.getyIndex()>0){
                    if(tmp[head.getxIndex()][head.getyIndex()-1]==false && field[(head.getxIndex())][head.getyIndex()-1]== true){
                        queue.addLast(new QueueElement(head.getxIndex(),head.getyIndex()-1,head.getRekRequest()+1));
                        tmp[head.getxIndex()][head.getyIndex()-1]=true;
                    }
                }
                //Feld rechts vom Start
                if(head.getxIndex()<field.length-1){
                    if(tmp[head.getxIndex()+1][head.getyIndex()]==false && field[(head.getxIndex()+1)][(head.getyIndex())]== true){
                        queue.addLast(new QueueElement(head.getxIndex()+1,head.getyIndex(),head.getRekRequest()+1));
                        tmp[head.getxIndex()+1][head.getyIndex()]=true;
                    }
                }
                //Feld unterhalb des Strat
                if(head.getyIndex()<field[0].length-1){
                    if(tmp[head.getxIndex()][head.getyIndex()+1]==false && field[(head.getxIndex())][(head.getyIndex()+1)]== true){
                        queue.addLast(new QueueElement(head.getxIndex(),head.getyIndex()+1,head.getRekRequest()+1));
                        tmp[head.getxIndex()][head.getyIndex()+1]=true;
                    }
                }
            }
        }
        return false;
    }  
        
}
