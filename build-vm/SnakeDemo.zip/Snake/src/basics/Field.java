/*
 * Field.java
 *
 * Created on 1. Dezember 2007, 17:53
 *
 * Durch diese Klasse wird das Zugreifen auf ein Feld aus Tile's erm�glicht.
 *
 */


package basics;

import java.io.*;
import java.util.Random;


/**
 * Durch diese Klasse wird das Zugreifen auf ein Feld aus Tile's erm�glicht.
 *
 * @author Reimar Schr�ter
 *         Alexander Grebhahn
 */

public class Field {
    private Tile[][] tileArray; // tileArray in dem alle Tile gespeichert sind
    private int indexX;
    private int indexY;
    private int tileSize=9;
    
    //Hilfsvariablen
    private String readData="";
    
    /**
     *
     * leerer Konstruktor von einem Field
     */
    public Field() {
        
    }
    
    /**
     *  Es wird ein neues Feld erzeugt, indem eine Karte aus einer Datei
     *  geladen wird.
     *
     *  @param path Speicherort der Datei wird angegeben, oder eigentliche Karte
     *  @param loadIntern gibt an ob die Level intern vom Jar geladen werden sollen
     */
    public Field(String path,boolean loadIntern){
            loadField(path,loadIntern);
    }
    
    
    
    
    /**
     *  Erstellt ein neues Field.
     *
     *  @param x Gr��e der darzustellenden Fl�che in X-Richtung
     *  @param y Gr��e der darzustellenden Fl�che in Y-Richtung
     *  @param xStart X-Position an der die Schlange gestartet werden soll
     *  @param yStart y-Position an der die Schlange gestartet werden soll
     *  @param size Gr��e in der die Tile dargestellt werden sollen
     *  @param backround MenueBackround?
     */
    public Field(int x, int y,int xStart,int yStart,int size,boolean backround){
        tileSize=size;
        indexX=x/size;
        indexY=y/size;
        tileArray=new Tile[indexX][indexY];
        Random rand=new Random();
        for(int m=0;m<indexX;m++){
            for(int n=0;n<indexY;n++){
                int rand1=rand.nextInt();
                if(rand1<0){
                    rand1=rand1*-1;
                }
                tileArray[m][n]=new Tile(m*size,n*size,2,rand1%4);
            }
        }
        if((indexX>=23 && indexY>7)&& backround){
            
            int startHeadPositionX = (indexX-23)/2;
            
            //S
            tileArray[startHeadPositionX+1][1]=new Tile((startHeadPositionX+1)*size,1*size,60,1);
            tileArray[startHeadPositionX+1][2]=new Tile((startHeadPositionX+1)*size,2*size,60,2);
            tileArray[startHeadPositionX+1][3]=new Tile((startHeadPositionX+1)*size,3*size,60,3);
            tileArray[startHeadPositionX+2][1]=new Tile((startHeadPositionX+2)*size,1*size,60,0);
            tileArray[startHeadPositionX+3][1]=new Tile((startHeadPositionX+3)*size,1*size,60,1);            
            tileArray[startHeadPositionX+2][3]=new Tile((startHeadPositionX+2)*size,3*size,60,2);
            tileArray[startHeadPositionX+3][3]=new Tile((startHeadPositionX+3)*size,3*size,60,3);
            tileArray[startHeadPositionX+3][4]=new Tile((startHeadPositionX+3)*size,4*size,60,0);
            tileArray[startHeadPositionX+3][5]=new Tile((startHeadPositionX+3)*size,5*size,60,1);
            tileArray[startHeadPositionX+2][5]=new Tile((startHeadPositionX+2)*size,5*size,60,2);
            tileArray[startHeadPositionX+1][5]=new Tile((startHeadPositionX+1)*size,5*size,60,3);            
            //N
            tileArray[startHeadPositionX+5][1]=new Tile((startHeadPositionX+5)*size,1*size,60,0);
            tileArray[startHeadPositionX+5][2]=new Tile((startHeadPositionX+5)*size,2*size,60,1);
            tileArray[startHeadPositionX+5][3]=new Tile((startHeadPositionX+5)*size,3*size,60,2);
            tileArray[startHeadPositionX+5][4]=new Tile((startHeadPositionX+5)*size,4*size,60,3);
            tileArray[startHeadPositionX+5][5]=new Tile((startHeadPositionX+5)*size,5*size,60,0);
            tileArray[startHeadPositionX+6][2]=new Tile((startHeadPositionX+6)*size,2*size,60,1);
            tileArray[startHeadPositionX+7][3]=new Tile((startHeadPositionX+7)*size,3*size,60,2);
            tileArray[startHeadPositionX+8][1]=new Tile((startHeadPositionX+8)*size,1*size,60,3);
            tileArray[startHeadPositionX+8][2]=new Tile((startHeadPositionX+8)*size,2*size,60,0);
            tileArray[startHeadPositionX+8][3]=new Tile((startHeadPositionX+8)*size,3*size,60,1);
            tileArray[startHeadPositionX+8][4]=new Tile((startHeadPositionX+8)*size,4*size,60,2);
            tileArray[startHeadPositionX+8][5]=new Tile((startHeadPositionX+8)*size,5*size,60,3);
            //A
            tileArray[startHeadPositionX+10][1]=new Tile((startHeadPositionX+10)*size,1*size,60,0);
            tileArray[startHeadPositionX+10][2]=new Tile((startHeadPositionX+10)*size,2*size,60,1);
            tileArray[startHeadPositionX+10][3]=new Tile((startHeadPositionX+10)*size,3*size,60,2);
            tileArray[startHeadPositionX+10][4]=new Tile((startHeadPositionX+10)*size,4*size,60,3);
            tileArray[startHeadPositionX+10][5]=new Tile((startHeadPositionX+10)*size,5*size,60,0);
            tileArray[startHeadPositionX+11][1]=new Tile((startHeadPositionX+11)*size,1*size,60,1);
            tileArray[startHeadPositionX+11][3]=new Tile((startHeadPositionX+11)*size,3*size,0,2);
            tileArray[startHeadPositionX+12][1]=new Tile((startHeadPositionX+12)*size,1*size,60,0);
            tileArray[startHeadPositionX+12][2]=new Tile((startHeadPositionX+12)*size,2*size,60,1);
            tileArray[startHeadPositionX+12][3]=new Tile((startHeadPositionX+12)*size,3*size,60,2);
            tileArray[startHeadPositionX+12][4]=new Tile((startHeadPositionX+12)*size,4*size,60,3);
            tileArray[startHeadPositionX+12][5]=new Tile((startHeadPositionX+12)*size,5*size,60,0);
            //K
            tileArray[startHeadPositionX+14][1]=new Tile((startHeadPositionX+14)*size,1*size,60,0);
            tileArray[startHeadPositionX+14][2]=new Tile((startHeadPositionX+14)*size,2*size,60,1);
            tileArray[startHeadPositionX+14][3]=new Tile((startHeadPositionX+14)*size,3*size,60,2);
            tileArray[startHeadPositionX+14][4]=new Tile((startHeadPositionX+14)*size,4*size,60,3);
            tileArray[startHeadPositionX+14][5]=new Tile((startHeadPositionX+14)*size,5*size,60,0);
            tileArray[startHeadPositionX+15][3]=new Tile((startHeadPositionX+15)*size,3*size,60,0);
            tileArray[startHeadPositionX+16][2]=new Tile((startHeadPositionX+16)*size,2*size,60,1);
            tileArray[startHeadPositionX+16][4]=new Tile((startHeadPositionX+16)*size,4*size,60,2);
            tileArray[startHeadPositionX+17][1]=new Tile((startHeadPositionX+17)*size,1*size,60,3);
            tileArray[startHeadPositionX+17][5]=new Tile((startHeadPositionX+17)*size,5*size,60,0);
            //E
            tileArray[startHeadPositionX+19][1]=new Tile((startHeadPositionX+19)*size,1*size,60,0);
            tileArray[startHeadPositionX+19][2]=new Tile((startHeadPositionX+19)*size,2*size,60,1);
            tileArray[startHeadPositionX+19][3]=new Tile((startHeadPositionX+19)*size,3*size,60,2);
            tileArray[startHeadPositionX+19][4]=new Tile((startHeadPositionX+19)*size,4*size,60,3);
            tileArray[startHeadPositionX+19][5]=new Tile((startHeadPositionX+19)*size,5*size,60,0);
            tileArray[startHeadPositionX+20][1]=new Tile((startHeadPositionX+20)*size,1*size,60,0);
            tileArray[startHeadPositionX+21][1]=new Tile((startHeadPositionX+21)*size,1*size,60,1);
            tileArray[startHeadPositionX+20][3]=new Tile((startHeadPositionX+20)*size,3*size,60,0);
            tileArray[startHeadPositionX+21][3]=new Tile((startHeadPositionX+21)*size,3*size,60,1);
            tileArray[startHeadPositionX+20][5]=new Tile((startHeadPositionX+20)*size,5*size,60,0);
            tileArray[startHeadPositionX+21][5]=new Tile((startHeadPositionX+21)*size,5*size,60,1);           
        }else{
            if(backround){
                tileArray[xStart][yStart]=new Tile(xStart*size,yStart*size,0,1);
            } else{
                tileArray[xStart][yStart]=new Tile(xStart*size,yStart*size,0,1);
                for(int l=0;l<indexY;l++){
                    if(l!=indexY/2){
                        int rand1=rand.nextInt();
                        if(rand1<0){
                            rand1=rand1*-1;
                        }
                        tileArray[indexX/2][l]=new Tile(indexX/2*size,l*size,60,rand1%4);
                        tileArray[indexX/2][l].setWalkable(false);
                    }
                }
            }
        }
    }
    
    /**
     *  Erstellt ein neues Field. 
     *  Die Gr��e ist mit x und y angegeben.
     *
     *  @param x Gr��e der darzustellenden Fl�che in X-Richtung
     *  @param y Gr��e der darzustellenden Fl�che in Y-Richtung
     */
    public Field(int x, int y){
       indexX=x/9;
       indexY=y/9;
       tileArray=new Tile[indexX][indexY];
       Random rand=new Random();
       for(int m=0;m<indexX;m++){
           for(int n=0;n<indexY;n++){
               int rand1=rand.nextInt();
               if(rand1<0){
                   rand1=rand1*-1;
               }
               tileArray[m][n]=new Tile(m*tileSize,n*tileSize,0,rand1%4);
           }
       }
    }
    
  /**
   *  Gibt den die Gr��e des Feldes in X-Richtung zur�ck.
   * 
   *  @return int Anzahl der Tile in x-Richtung
   *  
   */
  public int getIndexX(){
    return indexX;
  }
  
  /**
   *  Gibt den die Gr��e des Feldes in Y-Richtung zur�ck.
   * 
   *  @return int Anzahl der Tile in y-Richtung
   *  
   */
  public int getIndexY(){
    return indexY;
  }
  
  /**
   *  Hier wird die Karte aus einer Datei geladen, und als neues Feld abgelegt.
   * 
   *  @param path Speicherort der Datei
   *  @param loadIntern gibt an ob die level intern vom jar geladen werden sollen
   */
  private void loadField(String path,boolean loadIntern){
      String data="";
      try{
          InputStream fis = null;
          if(loadIntern){
              fis = getClass().getResourceAsStream(path);
          }
          else{
      //         FileConnection fc = (FileConnection)Connector.open(path,Connector.READ);
        //       fis = fc.openInputStream();
          }
          int readChar = -1;
          do {
              readChar = fis.read();              
              if (readChar != -1) {
                  data += (char)readChar;
              }
          } while (readChar != -1);
          fis.close();
      }
       catch(Exception e){
           System.err.println("Field: Fehler beim laden der Datei "+e.getMessage());
      }  
      readData=data;

      int xIndex=Integer.parseInt(getNextDataInformation());
      int yIndex=Integer.parseInt(getNextDataInformation());
      int size=Integer.parseInt(getNextDataInformation());
//      System.out.println(size);
      indexX=xIndex;
      indexY=yIndex;
      Tile [][] loadedArray=new Tile[xIndex][yIndex];
      for(int i=0;i<xIndex;i++){
        for(int l=0;l<yIndex;l++){
          Tile tile=new Tile();
          tile.setXPos(i*size);
          tile.setYPos(l*size);
          tile.setImgNr(Integer.parseInt(getNextDataInformation()));
          tile.setViewNr(Integer.parseInt(getNextDataInformation()));
          if(getNextDataInformation().charAt(0)=='t'){
        	  tile.setWalkable(true);
          }
          else{
        	  tile.setWalkable(false);
          }
          loadedArray[i][l]=tile;
        }
      }
      tileArray=loadedArray; 
  }
  
  /*
   *  Hier werden die einzelnen infos aus der Karte gesplittet
   *  ,diese Methode wird nur bei dem laden der Karte verwendet.
   * 
   *  @return String n�chste Information aus dem String
   */
  private String getNextDataInformation(){
      String info="";
      if(readData.length()>0){
          int endOfInfo1=readData.indexOf(" ");
          int endOfInfo2=readData.indexOf("\n");
          if(endOfInfo1<0&&endOfInfo2<0){
              return readData;
          }
          if((endOfInfo1+1<endOfInfo2)&&endOfInfo1>=0){
            info=readData.substring(0,endOfInfo1);
            readData=readData.substring(endOfInfo1+1);
          }
          else{
              info=readData.substring(0,endOfInfo2);
              readData=readData.substring(endOfInfo2+1);
          }    
      }
      else{
          return "";
      }
      return info;
  }
  
  /**
   *  Setzt die gr��e der Tile's im Array.
   * 
   *  @param tileSizeI neue Gr��e der Tiles im Array
   */
  public void setTileSize(int tileSizeI){
      tileSize=tileSizeI;
  }
  
  /**
   *  Gibt die Gr��e der Tile's im Array zur�ck.
   * 
   *  @return int Gr��e der Tile's im Array
   */
  public int getTileSize(){
	  return tileSize;
  }
    
  /**
   *  Diese Methode gibt ein Tile aus dem Array zur�ck, basierend auf den Indexwerten des Arrays.
   *  
   *  @param indX x-Index des Tile's im Array
   *  @param indY y-Index des Tile's im Array      
   *  @return Tile an der angegebenen Position im Array
   */
   public Tile getTile(int indX,int indY){
	  Tile tmp=tileArray[indX][indY].copy();
	  return tmp;
  }
   
  /**
   *  Diese Methode gibt ein Tile aus Array zur�ck, dazu wird nur die absolute Position im Field ben�tigt.
   *
   *  @param x x-Position des Tile's im Field
   *  @param y y-Position des Tile's im Field
   *  @return Tile an der angegebenen Position auf dem Field
   */
   public Tile getTileAbsolutPos(int x,int y){
	  Tile tmp=tileArray[x/tileSize][y/tileSize].copy();
	  return tmp;
   }
   
  /**
   *  Hier kann erfragt werden ob eine bestimmte Stelle des Feldes begehbar ist.
   *
   *  @param x absolute x-Position des Tile's im Field
   *  @param y absolute y-Position des Tile's im Field
   *  @return boolean Tile begehbar?   
   */
   public boolean getWalkableAbsolutPos(int x,int y ){
       return tileArray[x/tileSize][y/tileSize].getWakable();
   }
   
  /**
   *  Hier kann an einer bestimmten Stelle des Fields das Tile begehbar oder nicht begehbar gesetzt werden.
   *   
   *  @param x absolute x-Position des Tile's im Field
   *  @param y absolute y-Position des Tile's im Field    
   *  @param walkable ist das Tile begebar?
   */
   public void setWalkableAbsolutPos(int x,int y,boolean walkable){
       tileArray[x/tileSize][y/tileSize].setWalkable(walkable);
   }
    
   /**
    * Hier wird gesagt ob die eingebene Position sich auf einer Mittellinie eines Tile's ist.
    *
    * @param position 
    */
   public boolean isCenterOfTile(int position){
	   Main.sysout("gr��e der tile in der mitte -sollte int sein"+tileSize/2);
       if(position%tileSize==4*(tileSize/9)){
           return true;
       }
       return false;
   }
   
   /**
    *   Hier bekommt man das Tile von dem aus die Schlange gestartet werden soll.
    *
    *   @return Start-Tile der Schlange
    */
   private Tile getStartSnake(){
       Tile tmp=null;
       	  for(int i=0;i<indexX;i++){
	        for(int l=0;l<indexY;l++){
	        	if(tileArray[i][l].getImgNr()==0 || tileArray[i][l].getImgNr()==1){
	        		tmp=tileArray[i][l];    
	        	}       	
	        }
	  }
          return tmp;
   }
   
   /**
    *   Gibt die x-Position f�r den Start der Schlange zur�ck.
    *
    *   @return x-Position f�r den Startpunkt der Schlange
    */
   public int getXHoleSnake(){
      return getStartSnake().getXPos()+(tileSize/2);
   }
   
   /**
    *   Gibt die y-Position f�r den Start der Schlange zur�ck.
    *
    *   @return y-Position f�r den Startpunkt der Schlange
    */
   public int getYHoleSnake(){
       return getStartSnake().getYPos()+(tileSize/2);
   }
   
   
   /**
    *   Gibt ein boolean[][] zur�ck in der von jedem Tile die Begehbarkeit gespeichert sind.
    *
    *   @return Array mit den Begehbarkeit-Informationen zu jedem Tile
    */
   public boolean[][] getAllWalkable(){
       boolean[][] bool=new boolean[indexX][indexY];
       	  for(int i=0;i<indexX;i++){
	        for(int l=0;l<indexY;l++){
                       if(tileArray[i][l].getWakable()){
                           bool[i][l]=true;
                       }
                       else{
                           bool[i][l]=false; 
                       }
	        }
	  }
          return bool;
   }
   
   public void resizeField(int faktor){
	   this.tileSize=tileSize*faktor;
    	  for(int i=0;i<indexX;i++){
	        for(int l=0;l<indexY;l++){
	        	Tile tmp=tileArray[i][l];
	        	Tile tmpNewTile=tmp.copy();
	        	tmpNewTile.setSize(tileSize);
	        	tmpNewTile.setXPos(i*(tileSize));
	        	tmpNewTile.setYPos(l*(tileSize));
	        	tileArray[i][l]=tmpNewTile;
	        }
	  }
   }
}
