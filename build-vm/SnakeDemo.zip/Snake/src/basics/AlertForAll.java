package basics;

import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JPanel;

public class AlertForAll extends JPanel implements JPanelListener {
	String show="";
	Main main=null;

	public String getShow() {
		return show;
	}

	public void setShow(String show) {
		this.show = show;
	}

	public AlertForAll(Main main,String show) {
		
		
		super();
		this.main=main;
		this.show = show;
	}
	
	public void paint(Graphics g){
		Main.sysout(show.length());
		String[] stringArray=show.split(" ");
		String tmp="";
		g.fillRect(0,0,400,400);
		g.setColor(Color.WHITE);
		g.drawString(show, 0, 10);
	}

	@Override
	public void keyPressed(int arg0) {
		main.startMainMenu();
	}

}
