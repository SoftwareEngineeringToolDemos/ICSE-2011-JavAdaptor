/*
 * Tile.java
 *
 * Created on 1. Dezember 2007, 17:38
 *
 * Kachel eines Fields.
 */

package basics;

/**
 * Kachel eines Fields.
 *
 * @author Reimar Schr�ter
 *         Alexander Grebhahn
 */
public class Tile {
    protected int size=0;
    protected int xpos=0;
    protected int ypos=0;
    protected int imgNr;
    protected int viewNr=0;
    protected boolean walkable=true;
    
    /**
     * Kachel eines Fields.
     *
     * Konstruktor von einem Tile
     */
    public Tile() {
        
    }
    
    /**
     *  Konstruktor f�r ein Tile
     *  alle ben�tigten Informationen um ein Tile darzustelln, werden 
     *  �bergeben.
     *
     *  @param xpos1    x-Position des Tile
     *  @param ypos1    y-Position des Tile
     *  @param imgNr1    Bildnummer die dargestellt werden soll
     *  @param viewNr1   die genaue Darstellungsart des Bildes 
     */
    public Tile(int xpos1,int ypos1,int imgNr1,int viewNr1) {
        xpos=xpos1;
        ypos=ypos1;
        imgNr=imgNr1;
        viewNr=viewNr1;
    }
    
    /**
     *  Gibt die X-Position des Tile zur�ck.
     *
     *  @return x-Position
     *
     */
    public int getXPos(){
        return xpos;
    }
    
    /**
     *  Gibt die Y-Position des Tile zur�ck.
     *
     *  @return Y-Position
     *
     */
    public int getYPos(){
        return ypos;
    }
    
    /**
     *  Gibt die x, und die y-Position eines Tile in einem int[] zur�ck.
     *
     *  @return int[2] -Array mit der Position des Tile
     *
     */
    public int[] getPos(){
        int[] array=new int[2];
        array[0]=xpos;
        array[1]=ypos;
        return array;
    }
    
    /**
     *  Gibt die Image Nummer zur�ck (legt Bild fest).
     *
     *  @return Image-Nummer
     *
     */
    public int getImgNr(){
        return imgNr;
    }
    
    /**
     *  Setzt die Image Nummer.
     *
     *  @param imgNr1   neue Image-Nummer
     *
     */
    public void setImgNr(int imgNr1){
        imgNr=imgNr1;
    }
    
    /**
     *  Gibt true zur�ck wenn das Tile begehbar ist.
     *
     *  @return Begehbarkeit
     *
     */
    public boolean getWakable(){
        return walkable;
    }
    
    /**
     *  Setzt die Begehbarkeit eines Tile.
     *
     *  @param walk bei Begehbarkeit - True
     *
     */
    public void setWalkable(boolean walk){
        walkable=walk;
    }
    
    /**
     *  Setzt die x-Position des Tile neu.
     *
     *  @param x neue x-Position
     *
     */
    public void setXPos(int x){
        xpos=x;
    }
    
    
    /**
     *  Setzt die y-Position des Tile neu.
     *
     *  @param y neue y-Position
     *
     */
    public void setYPos(int y){
        ypos=y;
    }
    
    /**
     *  Gibt an welche Ansicht das Image haben soll(mehrere Varianten bei zb Stein).
     *
     *  @return   gibt das genaue Image an
     *
     */
    public int getViewNr(){
        return viewNr;
    }
    
    /**
     *  Setzt die genaue Ansicht des Tile (ein Stein zb kann in mehreren Varianten vorkommen).
     *
     *  @param viewNr1 neue Image Nummer f�r die genaue Ansicht
     *
     */
    public void setViewNr(int viewNr1){
        viewNr=viewNr1;
    }
    
    /**
     *  Gibt die Gr��e eines Tile zur�ck.
     *
     *  @return Gr��e des Tile
     *
     */
    public int getSize(){
        return size;
    }
    
    /**
     *  Setzt die Gr��e des Tile.
     *
     *  @param size1    neue Gr��e des Tile
     *
     */
    public void setSize(int size1){
        size=size1;
    }
    
    /**
     *  Kopiert ein Tile.
     *
     *  @return gibt das kopierte Tile zur�ck
     *
     */
    public Tile copy(){
    	Tile tmp=new Tile(this.getXPos(),this.getYPos(),this.getImgNr(),this.getViewNr());
    	tmp.setSize(size);
        tmp.setWalkable(this.getWakable());
    	return tmp;
    }
}
