/*
 * Menue.java
 *
 * Created on 24. November 2007, 22:29
 *
 * Durch diese Klasse wird das Spielfeld erzeugt und auf dem Display angezeigt.
 * Die Methode paint() wird durch die Klasse action immer wieder erneut aufgerufen.
 *
 */
package basics;

import entitys.Fly;
import entitys.Bug;
import entitys.Entity;
import entitys.EntityHelpings;
import entitys.Mouse;
import entitys.Slug;
import entitys.Snake;
import entitys.Centipede;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;
import java.util.Random;

import javax.swing.JComboBox;
import javax.swing.JPanel;


import paint.Painter;

/**
 * Durch diese Klasse wird das Spielfeld erzeugt und auf dem Display angezeigt.
 * Die Methode paint() wird durch die Klasse action immer wieder erneut aufgerufen.
 *
 * @author Reimar Schr�ter
 *         Alexander Grebhahn
 */
public class GameField extends JPanel implements JPanelListener{
	
    private int factor=1;
    private boolean startMenu=false;
    private int yheight = 0;//field.getIndexX() * ((Integer) main.elementSize.getSelectedItem());
    
    private boolean booleanToFastPushed=false;
    private int toFastPushed=-1;
    private Main main;
    private String[] menuElements={"Weiter","Men�","Ende"};
    private int center=0;
    private int selectedMenuPoint=0;
    private int numberMenuPoints=menuElements.length;
    
    
    public static int countEntity=10;
    private boolean forbidPaintAction=false;
    
    private boolean snakeIsActivated=false;
    private Field field;
    private boolean[][] fieldwithoutEntitys;
    public Painter painter; 
    private MyMath myMath;
    
    private Snake snake;
    
    public Object eatable;
    
    private Random rand;
    private PointDistribution points;
    
    int pushedKey=-1;
    int xpos;
    int ypos;
    
    int object=0;
    

    public GameField(Main main1,Field field1,Painter painter1,int livesCountI,PointDistribution pointsI) {
    	
    	factor=field1.getTileSize()/9;
    	forbidPaintAction=false;
        main =main1;
        painter=painter1;
        painter.newLevel();
        
      
        //setFullScreenMode(true); // sorgt f�r eine vollbildanzeige
        center=150;//getHeight()/2; //Mitte des Displays(in y-Richtung)

        rand = new Random();
        points= pointsI;//new PointDistribution();
        myMath = new MyMath();
        field=field1;//new Field("/level/level3.dat");
        new EntityHelpings(field,rand,factor);
        fieldwithoutEntitys=field.getAllWalkable();
        
        snake = new Snake(351,field.getYHoleSnake(),5,factor);
      
        this.snake = snake;

        repaint();
        Main.sysout(forbidPaintAction);
        yheight = field.getIndexX() * ((Integer) main.getElementSize().getSelectedItem());
        
        
    }

    /**
     * Testet ob die Schlange noch am Leben ist.
     *
     *  @return boolean noch am Leben?
     *
     */
    public boolean isAlive(){
        if(snake.getxPos()<0){
            return false;
        }
        if(snake.getyPos()<0){
            return false;
        }
        if(snake.getxPos()>field.getIndexX()*(9*factor)){
            return false;
        }
        if(snake.getyPos()>field.getIndexY()*(9*factor)){
            return false;
        }
        if(!snake.getHoleArrived()){
            if(field.getWalkableAbsolutPos(snake.getxPos(),snake.getyPos())==false){
                return false;
            }
        }
        return true;
    }
    
    
    //TODO update3 out : remove commenting from the line below
//	/* 
	public void paint(Graphics g) {
		Bug eatableEntitiy = null;
		if (eatable != null) {
			eatableEntitiy = (Bug) eatable;
		}

		if (main != null) {

			int xwidth = field.getIndexX()
					* ((Integer) main.getElementSize().getSelectedItem());
			int xheight = field.getIndexY()
					* ((Integer) main.getElementSize().getSelectedItem());
			if (!forbidPaintAction) {

				g.fillRect(0, 0, xwidth*2, yheight*2 - 40);
    			Font font = new Font("Arial", Font.PLAIN, 20);
    			g.setFont(font);
				g.setColor(Color.GREEN);
				g.drawString("Score: " +  points.getPointsNow(),0,17);
				if (!startMenu) {
					if (isAlive()) {

						if (eatableEntitiy != null) {
							snakeAutoMove(snake, eatableEntitiy.getxPos(),
									eatableEntitiy.getyPos(), field, true);
						} else {
							snakeAutoRotate();
						}

						if (pushedKey != -1) {
							Main.sysout(pushedKey);
							snakeTurn();
							booleanToFastPushed = false;
						}

						if (!Main.inReload) {
							snake.oneStep(field, countEntity);
							if (eatableEntitiy != null) {
								eatableEntitiy.oneStep(field);
								if (snake.alreadyMoved()) {
									int snakeIndexX = snake.getxPos()
											/ (9 * factor);
									int snakeIndexY = snake.getyPos()
											/ (9 * factor);
									int entIndexX = eatableEntitiy.getxPos()
											/ (9 * factor);
									int entIndexY = eatableEntitiy.getyPos()
											/ (9 * factor);
									if (snakeIndexX == entIndexX
											&& snakeIndexY == entIndexY) {
										snake.eat();
										if (eatableEntitiy.isA().equals("Bug")) {
											points.pointsBug((Bug) eatable);
										}
										if (countEntity != 0) {
											eatable = null;
										}
									}
								}
							}
						}
						pushedKey = -1;
						
						// TODO update2 update paint method	: remove commenting from next 4 lines
//						if (eatable == null){
//							eatable = EntityHelpings.newBug(rand, factor,
//									field, snake, fieldwithoutEntitys);
//						}
						
					System.out.println("ew");	
						
					} else {
						forbidPaintAction = true;
						g.fillRect(0, 0, getWidth(), getHeight());
						main.runningNextLevel(false);
					}

				}
				try {
					g.drawImage(painter
							.paintFrame(field, snake, eatableEntitiy), 0, 20,
							xwidth*2, xheight*2 + 20, 0, 0, field.getIndexX() * 9
									* factor, field.getIndexY() * 9 * factor,
							null);
				} catch (Exception e) {

				}
				if (startMenu) {
					menu();
					g.setColor(Color.RED);
					g.drawString(menuElements[(selectedMenuPoint
							+ numberMenuPoints - 1)
							% numberMenuPoints], 20, center - 20 + 10);
					g.drawString(menuElements[(selectedMenuPoint + 1)
							% numberMenuPoints], 20, center + 20 + 10);
					g.setColor(Color.WHITE);
					g.fillRect(0, center - 2, xwidth, 18);
					g.setColor(Color.RED);
					g.drawLine(0, center - 2, xwidth, center - 2);
					g.drawLine(0, center - 3, xwidth, center - 3);
					g.drawLine(0, center + 15, xwidth, center + 15);
					g.drawLine(0, center + 16, xwidth, center + 16);
					g.drawString(menuElements[(selectedMenuPoint)
							% numberMenuPoints], 20, center + 10);
				}
				if (toFastPushed != -1) {
					pushedKey = toFastPushed;
					toFastPushed = -1;
				}
			}
		}
	}
    //*/
    

    
	
//  TODO update3/4 update paint method : add (for update3) OR remove (for update4) commenting from the line below
	/*
	public void paint(Graphics g) {
		Entity eatableEntitiy = null;
		if (eatable != null) {
			eatableEntitiy = (Entity) eatable;
		}

		if (main != null) {

			int xwidth = field.getIndexX()
					* ((Integer) main.getElementSize().getSelectedItem());
			int xheight = field.getIndexY()
					* ((Integer) main.getElementSize().getSelectedItem());
			if (!forbidPaintAction) {

				g.fillRect(0, 0, xwidth*2, yheight*2 - 40);
				
				Font font = new Font("Arial", Font.PLAIN, 20);
		        g.setFont(font);
				g.setColor(Color.GREEN);
				g.drawString("Score: " +  points.getPointsNow(),0,17);
				if (!startMenu) {
					if (isAlive()) {

						if (eatableEntitiy != null) {
							if (eatableEntitiy instanceof Fly) {
								if (((Fly) eatableEntitiy).isFlying()) {
									snakeAutoMove(
											snake,
											((Fly) eatableEntitiy).getxPosAim(),
											((Fly) eatableEntitiy).getyPosAim(),
											field, true);
								} else {
									snakeAutoMove(snake, eatableEntitiy
											.getxPos(), eatableEntitiy
											.getyPos(), field, true);
								}
							} else {
								snakeAutoMove(snake, eatableEntitiy.getxPos(),
										eatableEntitiy.getyPos(), field, true);
							}
						} else {
							snakeAutoRotate();
						}

						if (pushedKey != -1) {
							Main.sysout(pushedKey);
							snakeTurn();
							booleanToFastPushed = false;
						}

						if (!Main.inReload) {

							snake.oneStep(field, countEntity);

							if (eatableEntitiy != null) {

								eatableEntitiy.oneStep(field);

								if (snake.alreadyMoved()) {

									if (eatableEntitiy.isA().equals("Fly")) {

										Fly fly = (Fly) eatableEntitiy;

										int abs = myMath.getDist(snake
												.getxPos(), snake.getyPos(),
												fly.getxPos(), fly.getyPos());

										if (abs < 36 && fly.isPossibleToFly()
												&& abs > 15) {
											fly.flyAway(myMath);
										} else {
											fly.walking(rand, myMath, field);
										}

										if (abs < (9 * factor)
												&& !fly.isFlying()) {
											snake.eat();
											points.pointsFly(fly);
											eatable = null;
										}
									} else {
										int snakeIndexX = snake.getxPos()
												/ (9 * factor);
										int snakeIndexY = snake.getyPos()
												/ (9 * factor);
										int entIndexX = eatableEntitiy
												.getxPos()
												/ (9 * factor);
										int entIndexY = eatableEntitiy
												.getyPos()
												/ (9 * factor);
										if (snakeIndexX == entIndexX
												&& snakeIndexY == entIndexY) {
											snake.eat();
											if (eatableEntitiy.isA().equals(
													"Bug")) {
												points.pointsBug((Bug) eatable);
											}
											if (countEntity != 0) {
												eatable = null;
											}
										}
									}
								}
							}
						}
						pushedKey = -1;
						if (eatable == null)
							eatable = Bug.newEntity(rand, factor, field, snake,
									fieldwithoutEntitys);
					} else {
						forbidPaintAction = true;
						g.fillRect(0, 0, getWidth(), getHeight());
						main.runningNextLevel(false);
					}
				}
				try {
					g.drawImage(painter
							.paintFrame(field, snake, eatableEntitiy), 0, 20,
							xwidth*2, xheight*2 + 20, 0, 0, field.getIndexX() * 9
									* factor, field.getIndexY() * 9 * factor,
							null);
				} catch (Exception e) {

				}
				if (startMenu) {
					menu();
					g.setColor(Color.RED);
					g.drawString(menuElements[(selectedMenuPoint
							+ numberMenuPoints - 1)
							% numberMenuPoints], 20, center - 20 + 10);
					g.drawString(menuElements[(selectedMenuPoint + 1)
							% numberMenuPoints], 20, center + 20 + 10);
					g.setColor(Color.WHITE);
					g.fillRect(0, center - 2, xwidth, 18);
					g.setColor(Color.RED);
					g.drawLine(0, center - 2, xwidth, center - 2);
					g.drawLine(0, center - 3, xwidth, center - 3);
					g.drawLine(0, center + 15, xwidth, center + 15);
					g.drawLine(0, center + 16, xwidth, center + 16);
					g.drawString(menuElements[(selectedMenuPoint)
							% numberMenuPoints], 20, center + 10);
				}
				if (toFastPushed != -1) {
					pushedKey = toFastPushed;
					toFastPushed = -1;
				}
			}
		}
	}
	//*/
    
    
    
    
	// TODO update4 update paint method : comment the line below
	/*
	public void paint(Graphics g) {
		Entity eatableEntitiy = null;
		if (eatable != null) {
			eatableEntitiy = (Entity) eatable;
		}

		if (main != null) {

			int xwidth = field.getIndexX()
					* ((Integer) main.getElementSize().getSelectedItem());
			int xheight = field.getIndexY()
					* ((Integer) main.getElementSize().getSelectedItem());
			if (!forbidPaintAction) {

				g.fillRect(0, 0, xwidth*2, yheight*2 - 40);
	
				Font font = new Font("Arial", Font.PLAIN, 20);
				g.setFont(font);
				g.setColor(Color.GREEN);
				g.drawString("Score: " +  points.getPointsNow(),0,17);
				if (!startMenu) {
					if (isAlive()) {

						if (eatableEntitiy != null) {
							if (eatableEntitiy instanceof Fly) {
								if (((Fly) eatableEntitiy).isFlying()) {
									snakeAutoMove(
											snake,
											((Fly) eatableEntitiy).getxPosAim(),
											((Fly) eatableEntitiy).getyPosAim(),
											field, true);
								} else {
									snakeAutoMove(snake, eatableEntitiy
											.getxPos(), eatableEntitiy
											.getyPos(), field, true);
								}
							} else {
								snakeAutoMove(snake, eatableEntitiy.getxPos(),
										eatableEntitiy.getyPos(), field, true);
							}
							if (snake.fullSize() > 13)
								snakeAutoMove(snake, field.getXHoleSnake(),
										field.getYHoleSnake(), field, false);
						} else {
							snakeAutoRotate();
						}

						if (pushedKey != -1) {
							Main.sysout(pushedKey);
							snakeTurn();
							booleanToFastPushed = false;
						}

						if (!Main.inReload) {

							snake.oneStep(field, countEntity);

							if (eatableEntitiy != null) {

								eatableEntitiy.oneStep(field);

								if (snake.alreadyMoved()) {

									if (eatableEntitiy.isA().equals("Fly")) {
										Fly fly = (Fly) eatableEntitiy;

										int abs = myMath.getDist(snake
												.getxPos(), snake.getyPos(),
												fly.getxPos(), fly.getyPos());

										if (abs < 36 && fly.isPossibleToFly()
												&& abs > 15) {
											fly.flyAway(myMath);
										} else {
											fly.walking(rand, myMath, field);
										}

										if (abs < (9 * factor)
												&& !fly.isFlying()) {
											snake.eat();
											points.pointsFly(fly);
											eatable = null;
										}
									} else {
										int snakeIndexX = snake.getxPos()
												/ (9 * factor);
										int snakeIndexY = snake.getyPos()
												/ (9 * factor);
										int entIndexX = eatableEntitiy
												.getxPos()
												/ (9 * factor);
										int entIndexY = eatableEntitiy
												.getyPos()
												/ (9 * factor);
										if (snakeIndexX == entIndexX
												&& snakeIndexY == entIndexY) {
											snake.eat();
											if (eatableEntitiy.isA().equals(
													"Bug")) {
												points.pointsBug((Bug) eatable);
											}
											if (countEntity != 0) {
												eatable = null;
											}
										}
									}

								}
							}
						}
						pushedKey = -1;
						if (eatable == null)
							eatable = Bug.newEntity(rand, factor,
									field, snake, fieldwithoutEntitys);
					} else {
						forbidPaintAction = true;
						g.fillRect(0, 0, getWidth(), getHeight());
						main.runningNextLevel(false);
					}

				}
				try {
					g.drawImage(painter.paintFrame(field, snake, eatableEntitiy), 0, 20,
							xwidth*2, xheight*2 + 20, 0, 0, field.getIndexX() * 9
									* factor, field.getIndexY() * 9 * factor,
							null);
				} catch (Exception e) {

				}

				if (startMenu) {
					menu();
					g.setColor(Color.RED);
					g.drawString(menuElements[(selectedMenuPoint
							+ numberMenuPoints - 1)
							% numberMenuPoints], 20, center - 20 + 10);
					g.drawString(menuElements[(selectedMenuPoint + 1)
							% numberMenuPoints], 20, center + 20 + 10);
					g.setColor(Color.WHITE);
					g.fillRect(0, center - 2, xwidth, 18);
					g.setColor(Color.RED);
					g.drawLine(0, center - 2, xwidth, center - 2);
					g.drawLine(0, center - 3, xwidth, center - 3);
					g.drawLine(0, center + 15, xwidth, center + 15);
					g.drawLine(0, center + 16, xwidth, center + 16);
					g.drawString(menuElements[(selectedMenuPoint)
							% numberMenuPoints], 20, center + 10);
				}

				if (toFastPushed != -1) {
					pushedKey = toFastPushed;
					toFastPushed = -1;
				}
			}
		}
	}
    //*/
    
    

	

	/**
     * Dreht die Schlange nach vorher definierten Tastendr�cken.
     *
     *
     */
    private void snakeTurn(){
    	Main.sysout("turn");
        if(!snake.getHoleArrived()){
            if(snakeIsActivated==false){
                snakeIsActivated=true;
                if(pushedKey==38){
                    snake.setRouteInt(0);
                }
                if(pushedKey==39){
                    snake.setRouteInt(1);
                }
                if(pushedKey==40){
                    snake.setRouteInt(2);
                }
                if(pushedKey==37){
                    snake.setRouteInt(3);
                }
                snake.routeFlow();
            }else{
                if(snake.getRouteInt()==0){
                    if(pushedKey==37){
                        snake.setRouteInt(3);
                    }
                    if(pushedKey==39){
                        snake.setRouteInt(1);
                    }
                }
                if(snake.getRouteInt()==1){
                    if(pushedKey==40){
                        snake.setRouteInt(2);
                    }
                    if(pushedKey==38){
                        snake.setRouteInt(0);
                    }
                }
                if(snake.getRouteInt()==2){
                    if(pushedKey==39){
                        snake.setRouteInt(1);
                    }
                    if(pushedKey==37){
                        snake.setRouteInt(3);
                    }
                }
                if(snake.getRouteInt()==3){
                    if(pushedKey==38){
                        snake.setRouteInt(0);
                    }
                    if(pushedKey==40){
                        snake.setRouteInt(2);
                    }
                }
            }
        }
    }
    
    /**
     *
     *  Speichert bzw bearbeitet die gedr�ckte Taste.
     *
     *  @param keyCode die gedr�ckte Taste
     */
    /*
    public void keyPressed(int keyCode) {
        if(!forbitPaintAction){
            if(booleanToFastPushed&&!startMenu){
             //   toFastPushed=getGameAction(keyCode);
            } else{
               // pushedKey=getGameAction(keyCode);
                if(!startMenu&&pushedKey!=8){
                    booleanToFastPushed=true;
                }
            }
            if(pushedKey==8){
                //menu();
                if(!startMenu){
                    MenueStart();
                }
            }
            if(startMenu){
                repaint();
            }
        }
    }
    */
    
    public void MenueStart(){	
        main.setBreak(false);
        Main.sysout("setFalse");
        startMenu=true;
        pushedKey=-2;
        repaint();
    }
    
    
    
    
    /**
     *  Verarbeitet die gedr�ckten Tasten wenn man sich im Menue befindet
     */
    public void menu(){
    	
        if(pushedKey==38){//oben
         //   main.clickMenu();
            selectedMenuPoint=(selectedMenuPoint+numberMenuPoints-1)%numberMenuPoints;  
        }
        if(pushedKey==40){//unten
           // main.clickMenu();
            selectedMenuPoint=(selectedMenuPoint+1)%numberMenuPoints;            
        }			
        Main.sysout(selectedMenuPoint);
        if(pushedKey==80||pushedKey==10){//best�tigen
            switch (selectedMenuPoint){
                case 0: startMenu=false; pushedKey=-1; main.setBreak(true);  break;
                case 1: main.startMainMenu();forbidPaintAction=true; break;
                case 2: //main.exit(); break;
            }
            repaint();
        }
        
    }

	public void keyPressed(int arg0) {
	
		//links 37, oben 38 rechts 39, unten 40
		Main.sysout("pressed");
	///	sysout(arg0.getSource().toString()+"  "+arg0.getKeyCode());
		int code=arg0;
		Main.sysout(forbidPaintAction);
		if((code>=37&&code<=40)||code==80||code==10){
		
        if(!forbidPaintAction){
            if(booleanToFastPushed&&!startMenu){
                toFastPushed=arg0;
            } else{
                pushedKey=arg0;
                if(!startMenu&&pushedKey!=80&&pushedKey!=10){
                    booleanToFastPushed=true;
                }
            }
            if(pushedKey==80||pushedKey==10){
            	
                //menu();
                if(!startMenu){
                    MenueStart();
                }
           }
           if(startMenu){
                repaint();
            }
        }

		}

	}

	//  autobewegung der Schlange
    int steps = 0;
    boolean isHorizontal = true;
    private boolean isInit = false;
    
    private void snakeAutoRotate() {
    	if(!isInit){
    		snake.setRouteInt(3);
    		isInit = true;
    	}
    	
    	steps++;
    	if(isHorizontal){
    		if(steps == 19){
    			isHorizontal = false;
    			steps = 0;
    			if(snake.getRouteInt()==1){
    				snake.setRouteInt(2);
    			}else{
    				snake.setRouteInt(0);
    			}
    		}
    	}else{
    		if(steps == 8){
    			isHorizontal = true;
    			steps = 0;
    			if(snake.getRouteInt()==2){
    				snake.setRouteInt(3);
    			}else{
    				snake.setRouteInt(1);
    			}
    		}
    	}
    }
    
    class Tupel{
 	   public int x;
 	   public int y;
 	   
 	   public Tupel(int x, int y){
 		   this.x = x;
 		   this.y = y;
 	   }
 	   
    }

    private void snakeAutoMove(Snake snake2, int entX, int entY,Field field2,boolean isEntity) {
		boolean[][] fieldsVisited = new boolean[field2.getAllWalkable().length][field2.getAllWalkable()[0].length];
		
		int snakeIndexX = snake.getxPos() / (9 * factor);
		int snakeIndexY = snake.getyPos() / (9 * factor);
		int entIndexX = entX / (9 * factor);
		int entIndexY = entY / (9 * factor);
		
		if(snakeIndexX == entIndexX  && snakeIndexY == entIndexY){
			if(!isEntity)
				main.runningNextLevel(true);
		}
		
		ArrayList<Tupel> fields = new ArrayList<Tupel>();
		fields.add(new Tupel(entIndexX, entIndexY));
		fieldsVisited[entIndexX][entIndexY] = true;
		
		boolean foundWay = false;
		do{
			boolean newAdded = false;
			if( (snakeIndexX != entIndexX) || (snakeIndexY != entIndexY)) {
				Tupel curr = (Tupel) fields.remove(0);
				int xIndex = curr.x,yIndex = curr.y;			
				// betrachte das Feld �ber dem aktuellen
				if(curr.y<fieldsVisited[0].length-1){
					xIndex = curr.x; yIndex = curr.y+1;
					if(!fieldsVisited[xIndex][yIndex]  && field2.getTile(xIndex,yIndex).walkable ){
						// pos der Schlange
						fieldsVisited[xIndex][yIndex] = true;
						if(xIndex == snakeIndexX && yIndex == snakeIndexY){
							snake.setRouteInt(0);
							foundWay = true;
							continue;
						}else{
							fields.add(new Tupel(xIndex, yIndex));
							newAdded = true;
						}
					}
				}
				// Feld links vom aktuellen
				if(curr.x>0){
					xIndex = curr.x-1; yIndex = curr.y;
					if(!fieldsVisited[xIndex][yIndex]  && field2.getTile(xIndex,yIndex).walkable ){
						// pos der Schlange
						fieldsVisited[xIndex][yIndex] = true;
						if(xIndex == snakeIndexX && yIndex == snakeIndexY){
							snake.setRouteInt(1);
							foundWay = true;
							continue;
						}else{
							fields.add(new Tupel(xIndex, yIndex));
							newAdded = true;
						}
						
					}
				}
				// Feld unter dem aktuellen
				if(curr.y>0){
					xIndex = curr.x; yIndex = curr.y-1;
					if(!fieldsVisited[xIndex][yIndex]  && field2.getTile(xIndex,yIndex).walkable ){
						// pos der Schlange
						fieldsVisited[xIndex][yIndex] = true;
						if(xIndex == snakeIndexX && yIndex == snakeIndexY){
							snake.setRouteInt(2);
							foundWay = true;
							continue;
						}else{
							fields.add(new Tupel(xIndex, yIndex));
							newAdded = true;
						}
					}
				}
				
				// Feld links vom aktuellen
				if(curr.x<fieldsVisited.length-1){
					xIndex = curr.x+1; yIndex = curr.y;
					if(!fieldsVisited[xIndex][yIndex]  && field2.getTile(xIndex,yIndex).walkable ){
						// pos der Schlange
						fieldsVisited[xIndex][yIndex] = true;
						if(xIndex == snakeIndexX && yIndex == snakeIndexY){
							snake.setRouteInt(3);
							foundWay = true;
							continue;
						}else{
							fields.add(new Tupel(xIndex, yIndex));
							newAdded = true;
						}
					}
				}
				if(!newAdded){
					if(fields.size() == 0){
						foundWay = true;
						continue;
					}
				}
			}else{
				
				
				
				foundWay = true;
				
				// problem ein Entrity wird gefressen und die schlange befindet sich in einer "halben" Sackgasse (sie darf nicht geradeaus weiterlaufen)
				
				
				
				System.out.println("m�sste essen ");
				System.out.println("Snake:   "+snakeIndexX+"   "+snakeIndexY  );
				System.out.println("Entity:  "+entIndexX+"   "+entIndexY  );
//				continue;
			}
		}while(!foundWay); 
		
		
		
		
	}
  
public void repaint2() {
	this.repaint();
}
}
