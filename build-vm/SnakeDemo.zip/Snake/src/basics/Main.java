/*
 *
 * Main.java
 * Created on 24. November 2007, 22:28
 *
 * Snake- Hier wird das komplette Spiel gesteuert.
 *
 */
package basics;

import java.awt.Color;
import java.awt.TextArea;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.InputStream;

import java.util.Timer;

import javax.swing.JApplet;
import javax.swing.JComboBox;
import javax.swing.JFrame;

import menu.Highscore;
import menu.MainMenu;

import paint.Painter;




/**
 * Snake- Hier wird das komplette Spiel gesteuert.
 *
 * @author  Alexander Grebhahn
 *          Reimar Schr�ter
 */
public class Main extends JFrame implements ActionListener {
	boolean wait=false;
	
	public static boolean inReload = false;
	
	TextField textField = new TextField();
	TextArea infoTextArea = new TextArea("test",400,50,TextArea.SCROLLBARS_VERTICAL_ONLY);
	JComboBox comboBox = null;
	private JComboBox elementSize = null;
	Main main = this;
	
	public void setWait(boolean wait) {
		this.wait = wait;
	}
	
	public static void sysout(Object o){
//		System.out.println(o.toString());
	}


	boolean initMenu=false;
//	MyKeyListener key=null;
	GameField gameField=null;
	Painter painter=null;
	
	
	public static void main(String[] args){
		new Main();
	}
	
	public Main(){
		
		addWindowListener(new java.awt.event.WindowAdapter(){public void windowClosing (java.awt.event.WindowEvent evt) {System.exit(0);}});
	    setSize(570,540);
	    setVisible(true);
	    setResizable(true);
	    setLayout(null);
	    setBackground(Color.white);
	    this.setTitle(System.getProperty("java.vendor"));
		
	     
		setLayout(null);
		this.start();	
	}
	
	
	
    boolean loadLevelIntern=false;
    private boolean loadLevelException=false;
  
 //   private MyRms myRms;
    private Action action=null; 
    private Timer t=null;
    private GameField level=null;
    private Field fieldLevel=null;
   // private Painter painter=null;
    private PointDistribution points=null;
    private int[] speed={300,120,160,200,300}; //Geschwindigkeit in der das Spiel absolviert wird
    private int lives=5; //Anzahl der Leben
    private int levelNow=0; //Level in dem sich die Schlange befindet
    private String[] nameLevel={""};   //Namen der Level die in dem Spiel existieren
     
    //Bild welches beim Start geladen werden soll
   // private LoadCanvas loadImage=new LoadCanvas();
   // private Alert infoAlert=new Alert("");  //Zwischeninformation zb zwischen den Leveln
    
    //Hauptmenue von dem alles gesteuert wird
    private MainMenu mainMenu=null;
    
    //Menuepunkt Highscore
    //private Form highscoreForm=null;
    //private ChoiceGroup challengeHighscore=null;
    //private TextField highscoreTextBox=null;
    private Highscore highscore=null;
    //private TextBox highscoreName=null;
    private int activeChallenge=2; // Die Schwierigkeit die gerade bei dem Spiel unter Einstellungen eingestellt wurde    
    
    //Menuepunkt Einstellungen
    ///private Form settings=null;
    //private ChoiceGroup challenge=null;
    //private ChoiceGroup allowVibration=null;
    //private ChoiceGroup volume=null;
    //private TextField InfoDisplay=null;
    
    //Menuepunkt Anleitung
    //private Form instructionForm =null;
    
    //Menuepunkt Impressum
    //private Form impressumForm =null;
    
    //Menuepunkt Level Pfad
    //private Form pathLevelForm=null;
   // private ChoiceGroup internExtern=null;
    //private TextField externLevelPath=null;
    
    //Sound
    // private MySound mySound=null;
    
    
    //private Command menuCmd = new Command("Men�", Command.SCREEN, 0);
    //private Command okCmd=new Command("OK",Command.SCREEN,0);
    //private Command okCmdSetPath=new Command("OK",Command.SCREEN,0);
    //private Command okCmdSetSettings=new Command("OK",Command.SCREEN,0);
    
/*
    public void commandAction(Command c, Displayable d) {
        if(c==menuCmd){            
            mainMenu.selected=0;
            Display.getDisplay(this).setCurrent(mainMenu);
        }
        
        if(okCmdSetSettings==c){
            myRms.writeMapSettings(new Integer(challenge.getSelectedIndex()).toString()+ 
                    "\n"+new Integer(allowVibration.getSelectedIndex()).toString()+
                    "\n"+new Integer(volume.getSelectedIndex()).toString());
            
            mainMenu.selected=0;
            Display.getDisplay(this).setCurrent(mainMenu);
        }
        
         if(c==okCmd){ 
            highscore.setNewHighscore(challenge.getSelectedIndex(),highscoreName.getString(),points.getPointsNow());
            this.startHighscore();
         }
        
        if(c==okCmdSetPath){
            String stringRmsSetPath="";  
            if(internExtern.getSelectedIndex()==0){
                stringRmsSetPath="i\n"+externLevelPath.getString();
            }else{
                stringRmsSetPath="e\n"+externLevelPath.getString();
                
                
            }
            myRms.writeSettings(stringRmsSetPath);
            mainMenu.selected=0;
              
            nameLevel=getLevelNames();
            
            
            if(loadLevelException){
                if(internExtern.getSelectedIndex()==1){
                    infoAlert.setString("Externer Pfad konnte nicht gefunden werden");
                    this.startMainMenu(infoAlert);
                } else{
                    if(internExtern.getSelectedIndex()==0){
                        infoAlert.setString("Keine internen Karten vorhanden");
                        this.startMainMenu(infoAlert);
                    } else{
                        this.startMainMenu(null);
                    }
                }
            } else{
                if(internExtern.getSelectedIndex()==1){
                    infoAlert.setString("Karten gefunden");
                    this.startMainMenu(infoAlert);
                } else{
                    this.startMainMenu(null);
                }
                
            }
            
        }
    }
    
    
    /**
     * 
     *  Eine Application wird gestarted. Alle Menuepunkte werden Vorbereitet.
     *
     *  Painter wird geladen ...
     *
     */
	
    public void start() { 
        //Vorbereitung des Menue Highscore
        highscore=new Highscore(null);

        
        
        
        textField.setEditable(false);
        textField.setFocusable(false);
        textField.setText("Schwierigkeitsgrad");
        
        comboBox =new JComboBox();
        comboBox.setEditable(false);
        comboBox.setBounds(0, 0, 200, 20);
        comboBox.addItem("sehr schwer");
        comboBox.addItem("schwer");
        comboBox.addItem("mittel");
        comboBox.addItem("leicht");
        comboBox.addItem("sehr leicht");
        comboBox.setFocusable(false);
       
        setElementSize(new JComboBox());
        getElementSize().setEditable(false);
        getElementSize().setBounds(0,0,200,20);
        getElementSize().addItem(12);
        getElementSize().addItem(14);
        getElementSize().addItem(16);
        getElementSize().addItem(18);
        getElementSize().setFocusable(false);
        
        elementSize.addItemListener(new ItemListener(){

			@Override
			public void itemStateChanged(ItemEvent arg0) {
				main.repaint();
				if(gameField!=null){
					gameField.repaint();
					
				}
				
				
			}
        	
        });
        
        add(textField).setBounds(0, 0, 200, 20);
        textField.setVisible(false);
    	add(comboBox).setBounds(0, 20, 200, 20);
    	comboBox.setVisible(false);
//    	add(getElementSize()).setBounds(0 , 20 , 200 , 20);
    	getElementSize().setVisible(false);
    	
        
        
        //levelnamen laden
        nameLevel=getLevelNames();
        
        //Sound
        //mySound=new PseudoSound();//new SoundNokia();
        infoTextArea.setEditable(false);
        infoTextArea.setFocusable(false);
        infoTextArea.setVisible(false);
        infoTextArea.setText("Um das Spiel zu starten gehen sie durch das Menu und bet�tigen Sie die Enter-Taste");
        add(infoTextArea).setBounds(0, 0, 400, 50);
        
        //Laden des Painter - l�ngste Dauer
        painter=new Painter(800,600);     
        mainMenu=new MainMenu(this,painter,new Field("/level/"+nameLevel[0]+".dat",true));
        
        
        //level=new GameField(this,fieldLevel,painter,lives,points);
//        key=new MyKeyListener();
       //this.startAlert();
        this.startMainMenu();

        
//        this.addKeyListener(key);
        //key.setListener(mainMenu);
        this.setFocusable(true);  
       // startGame();
    }   
    
    
    /**
     *  Startet das Highscore-Men�.
     */
    public void startHighscore(){
    	textField.setVisible(false);
    	comboBox.setVisible(false);
    	getElementSize().setVisible(false);
    	infoTextArea.setText("TODO");
    	infoTextArea.setVisible(true);
    	this.repaint();
    }
    
    /**
     *  Startet das Hauptmenue, vorher wird ein Alert angezeigt, wenn dieses nicht null ist.
     *
     * @param alert informative Anzeige vor Men�Start
     */
    public void startMainMenu(){
    	mainMenu.setVisible(true);
//    	key.setListener(mainMenu);
	    if(!initMenu){
	    	initMenu=true;
	      add(mainMenu).setBounds(0,50,600,600);
	    }
	    this.repaint();
    }
    
    /**
     *  L�sst das Handy vibrieren und managed den Sound, wenn dies bei Einstellungen erlaubt wurde.
     *
     *  @param isA  gibt die Art des Entity an
     */
	/*
    public void startEffects(String isA){
        if(allowVibration.getSelectedIndex()!=0&&isA!="flyingFly"){
            Display.getDisplay(this).vibrate(50*allowVibration.getSelectedIndex());
        }
        if(volume.getSelectedIndex()!=0){
            mySound.setVolume(volume.getSelectedIndex());
            if(isA=="Bug"){
                mySound.eatBug();
            }
            if(isA=="Slug"){
                mySound.eatSlug();
            }
            if(isA=="Mouse"){
                mySound.eatMouse();
            }
            if(isA=="flyingFly"){
                mySound.flyingFly();
            }
            if(isA=="Fly"){
                mySound.eatFly();
            }
            if(isA=="Centipede"){
                mySound.eatCentipede();
            }
        }
    }
    
    /**
     *  Startet Menue Einstellung
     */
    public void startSettings(){
    	textField.setVisible(true);
    	comboBox.setVisible(true);
    	getElementSize().setVisible(false);
    	infoTextArea.setVisible(false);
    	this.repaint();
    }
    
    /**
     *  Startet Menue Highscore
     */
    public void startInstruction(){    
    	textField.setVisible(false);
    	comboBox.setVisible(false);
    	getElementSize().setVisible(false);
    	infoTextArea.setText("Das Ziel dieses Spieles ist es, alle 10 auftauchenden Tierchen vollst�ndig zu fressen." +
    	                " Dabei sollte man auf unwegsames Gel�nde und auf seinen Schlangenschwanz achten. Nachdem alle Tierchen gefressen wurden," +
    	                " muss die Schlange wieder zum Loch gesteuert werden um das n�chste Level erreichen zu k�nnen. Bevor nicht alle Tierchen" +
    	                " gefressen wurden, kann die Schlange nicht wieder im Loch verschwinden.\n"+
    	                " Die Steuerung der Schlange kann mit Ihren Pfeil-Tasten erfolgen. Um in den Pausenmodus zu gelangen, kann die Enter-Taste oder die P-Taste benutzt werden. Die verschiedenen" +
    	                " Schwierigkeitsgrade k�nnen in dem Bereich" +
    	                " Einstellungen ver�ndert werden.");
    	infoTextArea.setVisible(true);
    	this.repaint();
    }
    
    /**
     *  Startet Menue Impressum
     */
    public void impressum(){
    	textField.setVisible(false);
    	comboBox.setVisible(false);
    	getElementSize().setVisible(false);
        infoTextArea.setText("Entwickelt von: \nAlexander Grebhahn \nReimar Schr�ter");
    	infoTextArea.setVisible(true);
    	this.repaint();
    }
    
    /**
     *  Startet Menue Karten.
     */
    public void startLevelPath(){
    	textField.setVisible(false);
    	comboBox.setVisible(false);
    	getElementSize().setVisible(false);
    	infoTextArea.setText("Diese Funktion steht nur f�r die Handyversion zur Verf�gung. \nW�hlen Sie einen anderen Men�-Punkt");
    	infoTextArea.setVisible(true);
    	this.repaint();
    }
    
    /**
     *  Startet das eigentliche Spiel (Erster Menuepunkt).
     */
	
    public void startGame(){  
    	infoTextArea.setVisible(false);
    	textField.setVisible(false);
    	comboBox.setVisible(false);
    	getElementSize().setVisible(true);
    	
        levelNow=0;
        lives=5;
        points= new PointDistribution();
        runningNextLevel(true);
    }
    
    /**
     *  Startet das n�chste Level, oder beendet das Spiel wenn kein Level vorhanden ist.
     * 
     * @param nextLevel gibt an ob die Schlange gestorben ist und das n�chste Level gestartet werden soll
     *          (nextLevel==false -so wird das gleiche Level aufgerufen)
     */
	
    public void runningNextLevel(boolean nextLevel){

        if(action!=null){
            action.setRun(false);
        }
        if(level!= null)
        	remove(level);
        level=null;
        fieldLevel=null;
        
        if(nextLevel){
            levelNow++;
            if(levelNow!=1){
    //            infoAlert.setString("N�chstes Level!!!");
            } else{
      //          infoAlert.setString("Viel Gl�ck!!!");
            }
        } else{
//            lives--;
        //    infoAlert.setString("Fehlversuch!!!");
        }
        
        if(lives==0){
        	sysout("keine leben mehr#");
            testHighscore(false);
        } else{

            //testet ob das Spiel komplett durchgespielt wurde
            if(levelNow<=nameLevel.length||nameLevel.length==0){
            //    infoAlert.setType(javax.microedition.lcdui.AlertType.CONFIRMATION);
             //   infoAlert.setTimeout(2500);
                //try{
                //erzeugt neues Spielfeld

                try{
                //    if(loadLevelException){
                  //      fieldLevel=new Field(400,400,0,0,9,false);
                   // } else{
                        //if(internExtern.getSelectedIndex()==0){

                            fieldLevel=new Field("/level/"+nameLevel[levelNow-1]+".dat",true);
                            fieldLevel.resizeField(2);
                       // } else{
                          //  fieldLevel=new Field(externLevelPath.getString()+nameLevel[levelNow-1]+".dat",false);
                        //}
                    //}
                    
                    //erzeugt neues GameField aus dem Spielfeld
                            sysout(levelNow+"levelnocw");
                     
                    if(level!= null){
                    	remove(level);
                    	removeAll();                  	
                    }
                    
                    level=new GameField(this,fieldLevel, new Painter(800,600),lives,points);
                    
                  
                   	add(level).setBounds(0, 0,1800,1600);

//                   	key = new MyKeyListener();
//                   	
//                    key.setListener(level);
                    mainMenu.setVisible(false);
                    this.repaint();
                	 
                   
                    //Display.getDisplay(this).setCurrent(infoAlert,level);
                    
                    //erzeugt eine Action die das spiel steuert, unterbricht sie und �bergibt das zu steuernde GameField
                    if(action==null)
                        action=new Action(this,level);
                      
                    action.setRun(false);
                    action.setGameField(level);
                    action.setTimeMillis(speed[comboBox.getSelectedIndex()]);
                    action.setRun(true);
                    action.setHighscoreRenew(false);

                    //startet den Timer mit der Action
                    if(t==null){
                        t=new Timer();
                        t.scheduleAtFixedRate(action,1000,1);
                    }
                }catch(Exception e){
                    //infoAlert.setString("Datenzugriff verweigert");
                    //infoAlert.setType(javax.microedition.lcdui.AlertType.CONFIRMATION);
                    //infoAlert.setTimeout(2500);
//                    this.startMainMenu();
                    e.printStackTrace();
                }
            } else{
//                testHighscore(true);
            }
        }
    }
    
    /**
     *  Testet ob der gegebene Punktwert ein Highscore ist und leitet alles weitere ein.
     * 
     * @param gameCompleted gibt an ob das Ende des Spiels erreicht wurde (ja-true)
     */
    private void testHighscore(boolean gameCompleted){
    	sysout("will testen");
        points.pointsRemaningLives(lives);
        if(false){//highscore.getPointsMinimal(challenge.getSelectedIndex())<points.getPointsNow()){
            if(!gameCompleted){
                //infoAlert.setString("Gl�ckwunsch!! Neuer Highscore!!!!");
            }
            else{
                //infoAlert.setString("Gl�ckwunsch,Spiel beendet!! Neuer Highscore!!!!");
            }
            //infoAlert.setType(javax.microedition.lcdui.AlertType.CONFIRMATION);
            //infoAlert.setTimeout(3000);
            //newHighscore(infoAlert);
        }
        else{
            if(!gameCompleted){
                //infoAlert.setString("Game Over");
                //infoAlert.setType(javax.microedition.lcdui.AlertType.CONFIRMATION);
                //infoAlert.setTimeout(3000);
                startMainMenu();
            }
            else{
                //infoAlert.setString("Spiel beendet! \nZu wenig Punkte f�r Highscore!");
                //infoAlert.setType(javax.microedition.lcdui.AlertType.CONFIRMATION);
                //infoAlert.setTimeout(3000);
                startMainMenu();
            }
        }
    }
    
    /**
     *  Tr�gt den neuen Highscore in die HighscoreListe ein.
     * 
     * @param infoAlertI    Alert was angezeigt werden soll, bevor der Eintrag erfolgt (kann auch null sein)
     */
	/*
    private void newHighscore(Alert infoAlertI){
        highscoreName.addCommand(okCmd);
        highscoreName.setCommandListener(this);
        if(infoAlertI==null){
            Display.getDisplay(this).setCurrent(highscoreName);
        }
        else{
            Display.getDisplay(this).setCurrent(infoAlertI,highscoreName);
        }
    }
   
    /**
     *
     * Verl�sst die Application.
     *
     */

    public void exit(){
    	textField.setVisible(false);
    	comboBox.setVisible(false);
    	getElementSize().setVisible(false);
    	infoTextArea.setText("Diese Funktion steht nur f�r die Handyversion zur Verf�gung. \nW�hlen Sie einen anderen Men�-Punkt");
    	infoTextArea.setVisible(true);
    	this.repaint();
    	
    }
    
    
    /**
     *
     * Geht in den Pausenmodus.
     *
     */
    /*
    public void pauseApp() {
        
    }
    */
    public void setBreak(boolean running){
        action.setRun(running);
    }
    
    /**
     *
     * Komplettes beenden des Spiels.
     *
     */
    
    public void destroyApp(boolean unconditional) {
    }
    
    public String[] getLevelNames(){
        String data="";
      try{
          InputStream fis;
    //      if(internExtern.getSelectedIndex()==0){
              fis = getClass().getResourceAsStream("/level/level.dat");
      //    }
        //  else{
          //     FileConnection fc = (FileConnection)Connector.open(externLevelPath.getString()+"level.dat",Connector.READ);//.open("file:///c:/Data/Other/level1.dat",Connector.READ_WRITE);
           //    fis = fc.openInputStream();
          //}
          int nextChar = -1;
          do {
              nextChar = fis.read();              
              if (nextChar != -1) {
                  data += (char)nextChar;
              }
          } while (nextChar != -1);
          fis.close();
          loadLevelException=false;
      }
       catch(Exception e){
           System.err.println("Field: Fehler beim laden der Datei "+e.getMessage());
           loadLevelException=true;
      }
      return getSubStrings(data);
    }
    
    
    
  /*
   *  Hier werden die einzelnen infos aus einem String geladen.
   * 
   *  @param readData String der gelesen wurde
   *  @return String n�chste Information aus dem String
   */
  private String[] getSubStrings(String readData){
      char[] dataCharArray=readData.toCharArray();
      int count=0;
      for(int i=0;i<dataCharArray.length;i++){
          if(dataCharArray[i]=='\n'){
              count++;
          }
      }
      count++;
      String substring="";
      String[] levelNames=new String[count];
      count=0;
      for(int i=0;i<dataCharArray.length+1;i++){
        if(i==dataCharArray.length || dataCharArray[i]=='\n'){
            levelNames[count]=substring;
            substring="";
            count++;
        }
        else{
            substring+=dataCharArray[i];
        }
      }
      return levelNames;
  }

@Override
public void actionPerformed(ActionEvent arg0) {
	
}

public void setElementSize(JComboBox elementSize) {
	this.elementSize = elementSize;
}

public JComboBox getElementSize() {
	return elementSize;
}
}
