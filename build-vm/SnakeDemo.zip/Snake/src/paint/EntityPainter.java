/*
 * EntityPainter.java
 *
 * Created on 10. Januar 2008, 21:29
 *
 * Hier werden alle Entitys auf den Hintergurnd gemalt. 
 *
 */

package paint;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;

import javax.imageio.ImageIO;

import basics.Main;

import entitys.Bug;
import entitys.Entity;
import entitys.Fly;
import entitys.Mouse;
import entitys.Slug;
import entitys.SlugPart;
import entitys.Snake;
import entitys.SnakePart;
import entitys.Centipede;





/**
 * Hier werden alle Entitys auf den Hintergurnd gemalt
 *
 * @author  Alexander Grebhahn
 *          Reimar Schr�ter
 */
public class EntityPainter {
    
	protected static  int bigBildDim=11;
	protected static int smallBildDim=9;    
    
    
    //Snake Image Zeilen
	protected static int snakeHead=0;
	protected static int snakeMiddle=1;
	protected static int snakeEdge=2;
	protected static int snakeTale=3;
	protected static int snakeMiddleDouble=4;
	protected static int snakeStartBall=5;
	protected static int snakeEdgeDouble=6;
	protected static int snakeLochAnge=7;
        
    //Bug Image Zeilen
	protected static int bugI=8;
	protected static int bugII=9;        
	protected static int bugIII=10;
	protected static int bugIV=11;
    
    //Slug Image Zeilen
	protected static int slugI=18;
	protected static int slugSlime = 12;
    
    //Tausend Image Zeilen
	protected static int centiIHead=0;
    protected static int centiIMiddle=1;
    protected static int centiITale=2;
    protected static int centiIIHead=3;
    protected static int centiIIMiddle=4;
    protected static int centiIITale=5;
    protected static int centiIEdge=6;
    protected static int centiIIEdge=7;
    protected static int centiDead=8;    
    protected static int centiLeaf=9;
    
    //Mouse Image Zeilen
    protected static int mouseHead=13;
    protected static int mouseTale=14;
    protected static int mouseHeadDead=15;
    protected static int mouseTaleDead=16;
    
    //Fly Image Zeilen
    protected static int flyBig=17;
    protected static int flySmall=10;
    
    protected static int xPicture;
    protected static int yPicture;
    
    protected static Image entityPictures=null;
    protected static Image entityPictures9=null;
    
    
    /**
     *
     * Das Bild mit den Entitys wird eingelesen und in arrays gepeichert.
     *
     * @param xPictureI Frame Gr��e in X-Richtung
     * @param yPictureI Frame Gr��e in Y-Richtung
     * 
     */
    static{
    	String entitys="/picture/entity.png";
        String entitys9="/picture/entity9.png";
        try{
            entityPictures=ImageIO.read(Painter.class.getResource(entitys));
            
        } catch(Exception e){
            Main.sysout("EntityPainter: Fehler beim Laden des ersten Bildes(11er Bild)");
        }
        try{
            entityPictures9=ImageIO.read(Painter.class.getResource(entitys9));
        } catch(Exception e){
            Main.sysout("EntityPainter: Fehler beim Laden des zweiten Bildes(9er Bild)");
        }
    }
    
//-------------------------------------------------------------------------------------------------------------------------------
    
    
    /**
     *
     * Hier werden alle �bergebenen Entitys auf ein Image gezeichnet.
     *
     * @param backround 
     * @param entities das Array der zu zeichnenden Entitys
     *
     */
    
    public static Image paintBug(Image backround,Snake snake, Bug bug){
    	BufferedImage frame=new BufferedImage(xPicture,yPicture, BufferedImage.TYPE_INT_ARGB);
            //Image frame=new Image(5,20);//Image.createImage(xPicture,yPicture);
            Graphics g=frame.getGraphics();
                   
            g.drawImage(backround,0,0,null);
            
            if(!snake.alreadyMoved()){
                paintSnake(g,(Snake)snake);
            }        
            if(bug!=null){
	            paintBug(g,(Bug)bug);
            }    
	        if(snake.alreadyMoved()){
	        	paintSnake(g,(Snake)snake);
	        }
        return frame;
    }
    

//    
    private static void smallPicturePaint(Graphics g,int xPosEntityPicture, int yPosEntityPicture, int xPosField, int yPosField ,int size){
        g.drawImage(entityPictures9,xPosField,yPosField,xPosField+size,yPosField+size,xPosEntityPicture*smallBildDim,yPosEntityPicture*smallBildDim,xPosEntityPicture*smallBildDim+smallBildDim,yPosEntityPicture*smallBildDim+smallBildDim,null);
    }
    
    private static void smallPicturePaint(Graphics g,int xPosEntityPicture, int yPosEntityPicture, int xPosField, int yPosField ){
    	 g.drawImage(entityPictures9,xPosField,yPosField,xPosField+9,yPosField+9,xPosEntityPicture*smallBildDim,yPosEntityPicture*smallBildDim,xPosEntityPicture*smallBildDim+smallBildDim,yPosEntityPicture*smallBildDim+smallBildDim,null);
    }
    
    private static void bigPicturePaint(Graphics g,int xPosEntityPicture, int yPosEntityPicture, int xPosField, int yPosField,int size ){
        g.drawImage(entityPictures,xPosField,yPosField,xPosField+size,yPosField+size,xPosEntityPicture*bigBildDim,yPosEntityPicture*bigBildDim,xPosEntityPicture*bigBildDim+bigBildDim,yPosEntityPicture*bigBildDim+bigBildDim,null);
    }
    
    private void bigPicturePaint(Graphics g,int xPosEntityPicture, int yPosEntityPicture, int xPosField, int yPosField ){
        g.drawImage(entityPictures,xPosField,yPosField,xPosField+11,yPosField+11,xPosEntityPicture*bigBildDim,yPosEntityPicture*bigBildDim,xPosEntityPicture*bigBildDim+bigBildDim,yPosEntityPicture*bigBildDim+bigBildDim,null);
    }
    
    
    static void paintFly(Graphics g,Fly fly){
        if(fly.isFlying()){
            bigPicturePaint(g,fly.getRoute(),flyBig,fly.getminXPos(),fly.getminYPos(),(fly.stepsize()/3)*9);
        }else{
            smallPicturePaint(g,fly.getRoute(),flySmall,fly.getminXPos(),fly.getminYPos(),(fly.stepsize()/3)*9);
        }
    }    
    
    private static void paintTausend(Graphics g,Centipede centi){
        smallPicturePaint(g,centi.getLeaf().getStatus(),centiLeaf,centi.getLeaf().getminxPos(),centi.getLeaf().getminyPos(),9*centi.getFaktor());
    
        //Tausendf��ler zeichnen
        
        //Kopf zeichnen
        if(centi.getPart(0).isAlive()){
            if(!centi.isAlive()){
                smallPicturePaint(g,0,centiDead,centi.getPart(0).getminxPos(),centi.getPart(0).getminyPos(),9*centi.getFaktor());
            }else{
                if(centi.getStatus()%2==0){
                    smallPicturePaint(g,centi.getPart(0).getRoute(),centiIHead,centi.getPart(0).getminxPos(),centi.getPart(0).getminyPos(),9*centi.getFaktor());
                }else{
                    smallPicturePaint(g,centi.getPart(0).getRoute(),centiIIHead,centi.getPart(0).getminxPos(),centi.getPart(0).getminyPos(),9*centi.getFaktor());
                }
            }
        }
        //mittelteile
        for(int i=1;i<centi.getLength()-1;i++){
            if(centi.getPart(i).isAlive()){
                if(centi.isAlive()){
                    if(centi.getPart(i).getRoute()==centi.getPart(i+1).getRoute()){
                        if(centi.getStatus()%2==0){
                            smallPicturePaint(g,centi.getPart(i).getRoute(),centiIMiddle,centi.getPart(i).getminxPos(),centi.getPart(i).getminyPos(),9*centi.getFaktor());
                        }else{
                            smallPicturePaint(g,centi.getPart(i).getRoute(),centiIIMiddle,centi.getPart(i).getminxPos(),centi.getPart(i).getminyPos(),9*centi.getFaktor());
                        }
                    }else{
                        // Ecken
                        if(centi.getStatus()%2==0){
                            if(centi.getPart(i).getRoute()==3 && centi.getPart(i+1).getRoute()==0){
                                smallPicturePaint(g,1,centiIIEdge,centi.getPart(i).getminxPos(),centi.getPart(i).getminyPos(),9*centi.getFaktor());
                            }
                            if(centi.getPart(i).getRoute()==0 && centi.getPart(i+1).getRoute()==1){
                                smallPicturePaint(g,2,centiIIEdge,centi.getPart(i).getminxPos(),centi.getPart(i).getminyPos(),9*centi.getFaktor());
                            }
                            if(centi.getPart(i).getRoute()==2 && centi.getPart(i+1).getRoute()==3){
                                smallPicturePaint(g,0,centiIIEdge,centi.getPart(i).getminxPos(),centi.getPart(i).getminyPos(),9*centi.getFaktor());
                            }
                            if(centi.getPart(i).getRoute()==1 && centi.getPart(i+1).getRoute()==2){
                                smallPicturePaint(g,3,centiIIEdge,centi.getPart(i).getminxPos(),centi.getPart(i).getminyPos(),9*centi.getFaktor());
                            }
                            if(centi.getPart(i).getRoute()==0 && centi.getPart(i+1).getRoute()==3){
                                smallPicturePaint(g,3,centiIEdge,centi.getPart(i).getminxPos(),centi.getPart(i).getminyPos(),9*centi.getFaktor());
                            }
                            if(centi.getPart(i).getRoute()==3 && centi.getPart(i+1).getRoute()==2){
                                smallPicturePaint(g,2,centiIEdge,centi.getPart(i).getminxPos(),centi.getPart(i).getminyPos(),9*centi.getFaktor());
                            }
                            if(centi.getPart(i).getRoute()==2 && centi.getPart(i+1).getRoute()==1){
                                smallPicturePaint(g,1,centiIEdge,centi.getPart(i).getminxPos(),centi.getPart(i).getminyPos(),9*centi.getFaktor());
                            }
                            if(centi.getPart(i).getRoute()==1 && centi.getPart(i+1).getRoute()==0){
                                smallPicturePaint(g,0,centiIEdge,centi.getPart(i).getminxPos(),centi.getPart(i).getminyPos(),9*centi.getFaktor());
                            }
                        }else{
                            if(centi.getPart(i).getRoute()==3 && centi.getPart(i+1).getRoute()==0){
                                smallPicturePaint(g,1,centiIEdge,centi.getPart(i).getminxPos(),centi.getPart(i).getminyPos(),9*centi.getFaktor());
                            }
                            if(centi.getPart(i).getRoute()==0 && centi.getPart(i+1).getRoute()==1){
                                smallPicturePaint(g,2,centiIEdge,centi.getPart(i).getminxPos(),centi.getPart(i).getminyPos(),9*centi.getFaktor());
                            }
                            if(centi.getPart(i).getRoute()==2 && centi.getPart(i+1).getRoute()==3){
                                smallPicturePaint(g,0,centiIEdge,centi.getPart(i).getminxPos(),centi.getPart(i).getminyPos(),9*centi.getFaktor());
                            }
                            if(centi.getPart(i).getRoute()==1 && centi.getPart(i+1).getRoute()==2){
                                smallPicturePaint(g,3,centiIEdge,centi.getPart(i).getminxPos(),centi.getPart(i).getminyPos(),9*centi.getFaktor());
                            }
                            if(centi.getPart(i).getRoute()==0 && centi.getPart(i+1).getRoute()==3){
                                smallPicturePaint(g,3,centiIIEdge,centi.getPart(i).getminxPos(),centi.getPart(i).getminyPos(),9*centi.getFaktor());
                            }
                            if(centi.getPart(i).getRoute()==3 && centi.getPart(i+1).getRoute()==2){
                                smallPicturePaint(g,2,centiIIEdge,centi.getPart(i).getminxPos(),centi.getPart(i).getminyPos(),9*centi.getFaktor());
                            }
                            if(centi.getPart(i).getRoute()==2 && centi.getPart(i+1).getRoute()==1){
                                smallPicturePaint(g,1,centiIIEdge,centi.getPart(i).getminxPos(),centi.getPart(i).getminyPos(),9*centi.getFaktor());
                            }
                            if(centi.getPart(i).getRoute()==1 && centi.getPart(i+1).getRoute()==0){
                                smallPicturePaint(g,0,centiIIEdge,centi.getPart(i).getminxPos(),centi.getPart(i).getminyPos(),9*centi.getFaktor());
                            }
                        }
                    }
                }else{
                    smallPicturePaint(g,0,centiDead,centi.getPart(i).getminxPos(),centi.getPart(i).getminyPos(),9*centi.getFaktor());
                }
            }
        }        
        //Tale
        if(centi.getPart(4).isAlive()){
            if(centi.isAlive()){
                if(centi.getStatus()%2==0){
                    smallPicturePaint(g,centi.getPart(4).getRoute(),centiITale,centi.getPart(4).getminxPos(),centi.getPart(4).getminyPos(),9*centi.getFaktor());
                }else{
                    smallPicturePaint(g,centi.getPart(4).getRoute(),centiIITale,centi.getPart(4).getminxPos(),centi.getPart(4).getminyPos(),9*centi.getFaktor());
                }
            }else{
                smallPicturePaint(g,0,centiDead,centi.getPart(4).getminxPos(),centi.getPart(4).getminyPos(),9*centi.getFaktor());
            }
        }
    }

    
    private static void paintSlug(Graphics g,Slug slug){
        SlugPart tmp = slug.getHead();
        while(tmp.getNext()!=null){
            tmp=tmp.getNext();
            bigPicturePaint(g,0,slugSlime,tmp.getminxPos(),tmp.getminyPos(),(slug.stepsize()/3)*9);
        }
        bigPicturePaint(g,slug.getHead().getRoute(),slugI,slug.getHead().getminxPos(),slug.getHead().getminyPos(),(slug.stepsize()/3)*9);
    }
    
    static void paintBug(Graphics g,Bug bug){
        int status =bug.getStatus();
        if(status %4==0){
            bigPicturePaint(g,bug.getRoute(),bugII,bug.getminXPos(),bug.getminYPos(),(bug.stepsize()/3)*9);
        }
        if(status %4==1){
            bigPicturePaint(g,bug.getRoute(),bugI,bug.getminXPos(),bug.getminYPos(),(bug.stepsize()/3)*9);
        }
        if(status % 4==2){
            bigPicturePaint(g,bug.getRoute(),bugIII,bug.getminXPos(),bug.getminYPos(),(bug.stepsize()/3)*9); 
        }
        if(status % 4==3){
           bigPicturePaint(g,bug.getRoute(),bugIV,bug.getminXPos(),bug.getminYPos(),(bug.stepsize()/3)*9);         
        }    
    }
    
    static void paintSnake(Graphics g, Snake snake){
        SnakePart tmp = snake.getTale();
        if(!snake.alreadyMoved()){
            bigPicturePaint(g,2,snakeMiddle,tmp.getminxPos(),tmp.getminyPos(),snake.getSize());
        }else{
            //Tale Zeichnen
            if(tmp.getxPos()==tmp.getPrev().getxPos() && tmp.getyPos() == tmp.getPrev().getyPos()){
                bigPicturePaint(g,tmp.getRouteInt(),snakeStartBall,tmp.getminxPos(),tmp.getminyPos(),snake.getSize());
            }else{
                bigPicturePaint(g,tmp.getRouteInt(),snakeTale,tmp.getminxPos(),tmp.getminyPos(),snake.getSize());
            }
            tmp=tmp.getPrev();
            //Middle Zeichnen
            while(tmp.getTyp().equals("middle")){
                if(snake.getHoleArrived() && tmp.getxPos()==snake.getHead().getxPos() && tmp.getyPos()==snake.getHead().getyPos()){
                    bigPicturePaint(g,tmp.getRouteInt(),snakeStartBall,tmp.getminxPos(),tmp.getminyPos(),snake.getSize());
                }else{
                    //geraden Mittelst�cke
                    if(tmp.getRouteInt()==tmp.getNext().getRouteInt()){
                        // doppelte
                        if((tmp.getxPos()==tmp.getNext().getxPos()) && (tmp.getyPos() == tmp.getNext().getyPos())){
                            
                            bigPicturePaint(g,tmp.getRouteInt()%2,snakeMiddleDouble,tmp.getminxPos(),tmp.getminyPos(),snake.getSize());
                        }else{
                            bigPicturePaint(g,tmp.getRouteInt()%2,snakeMiddle,tmp.getminxPos(),tmp.getminyPos(),snake.getSize());
                        }
                        //ecken Mittelst�cken
                    }else{
                        // doppelte
                        if((tmp.getxPos()==tmp.getNext().getxPos()) && (tmp.getyPos() == tmp.getNext().getyPos())){
                            if((tmp.getRouteInt()==0 && tmp.getNext().getRouteInt()==1) || (tmp.getRouteInt()==3 && tmp.getNext().getRouteInt()==2)){
                                bigPicturePaint(g,3,snakeEdgeDouble,tmp.getminxPos(),tmp.getminyPos(),snake.getSize());
                            }
                            if((tmp.getRouteInt()==1 && tmp.getNext().getRouteInt()==0) || (tmp.getRouteInt()==2 && tmp.getNext().getRouteInt()==3)){
                                bigPicturePaint(g,0,snakeEdgeDouble,tmp.getminxPos(),tmp.getminyPos(),snake.getSize());
                            }
                            if((tmp.getRouteInt()==1 && tmp.getNext().getRouteInt()==2) || (tmp.getRouteInt()==0 && tmp.getNext().getRouteInt()==3)){
                                bigPicturePaint(g,2,snakeEdgeDouble,tmp.getminxPos(),tmp.getminyPos(),snake.getSize());
                            }
                            if((tmp.getRouteInt()==3 && tmp.getNext().getRouteInt()==0) || (tmp.getRouteInt()==2 && tmp.getNext().getRouteInt()==1)){
                                bigPicturePaint(g,1,snakeEdgeDouble,tmp.getminxPos(),tmp.getminyPos(),snake.getSize());
                            }
                        }else{
                            if((tmp.getRouteInt()==0 && tmp.getNext().getRouteInt()==1) || (tmp.getRouteInt()==3 && tmp.getNext().getRouteInt()==2)){
                                bigPicturePaint(g,3,snakeEdge,tmp.getminxPos(),tmp.getminyPos(),snake.getSize());
                            }
                            if((tmp.getRouteInt()==1 && tmp.getNext().getRouteInt()==0) || (tmp.getRouteInt()==2 && tmp.getNext().getRouteInt()==3)){
                                bigPicturePaint(g,0,snakeEdge,tmp.getminxPos(),tmp.getminyPos(),snake.getSize());
                            }
                            if((tmp.getRouteInt()==1 && tmp.getNext().getRouteInt()==2) || (tmp.getRouteInt()==0 && tmp.getNext().getRouteInt()==3)){
                                bigPicturePaint(g,2,snakeEdge,tmp.getminxPos(),tmp.getminyPos(),snake.getSize());
                            }
                            if((tmp.getRouteInt()==3 && tmp.getNext().getRouteInt()==0) || (tmp.getRouteInt()==2 && tmp.getNext().getRouteInt()==1)){
                                bigPicturePaint(g,1,snakeEdge,tmp.getminxPos(),tmp.getminyPos(),snake.getSize());
                            }
                        }
                    }
                }
                tmp=tmp.getPrev();
            }
            //Head zeichnen
            if(!snake.getHoleArrived()){
                bigPicturePaint(g,tmp.getRouteInt(),snakeHead,tmp.getminxPos(),tmp.getminyPos(),snake.getSize());
            }else{
                bigPicturePaint(g,tmp.getRouteInt(),snakeLochAnge,tmp.getminxPos(),tmp.getminyPos(),snake.getSize());
            }
        }
    }
}
