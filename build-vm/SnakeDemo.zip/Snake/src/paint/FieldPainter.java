/*
 * FieldPainter.java
 *
 * Created on 27. November 2007, 13:56
 *
 * 
 * Malt das �bergeben Field.
 *
 */




package paint;


// Import der Java Packages
import basics.Field;
import basics.GameField;
import basics.Main;
import basics.Tile;

import javax.imageio.ImageIO;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;

public class FieldPainter {
    static int width=0;
    static int height=0;
    static Image[][] array=new Image[85][4];
    static Image background;
    static Image tileset=null;
    static String root="/picture/tileset.png";
   
    public FieldPainter(int widthI, int heightI) {
        background=null;
        width=widthI;
        height=heightI;
        
        try{
            tileset=ImageIO.read(Painter.class.getResource(root));//Image.createImage(root);
        } catch(Exception e){
            Main.sysout("Painter: error while loading the image");
        }
        for(int x=0; x<36;x=x+9){
            for(int y=0;y<(85*9);y=y+9){
            	BufferedImage tmp=new BufferedImage(9,9, BufferedImage.TYPE_INT_ARGB);
                Graphics g=tmp.getGraphics();
                array[y/9][x/9]=tmp;
            }
        }
    }
    
    public static void newLevel(){
        background=null;
    }
    
    public static boolean b = false;
	public static Image paintField(Field field) {

		background = new BufferedImage(width, height,
				BufferedImage.TYPE_INT_ARGB);

		if(!b){
			System.out.println(FieldPainter.class);
			b=true;
		}
//		TODO update1 PaintField : remove comment from next line
//		paintFieldInit(background.getGraphics(), field);
		
		return background;
	}

	// TODO update1 PaintField : comment the next line
	/*
	private static void paintFieldInit(Graphics g, Field field) {
		int tilesize = field.getTileSize();
		try {
			tileset = ImageIO.read(Painter.class.getResource(root));
		} catch (Exception e) {
			e.printStackTrace();
		}
		for (int x = 0; x < 36; x = x + 9) {
			for (int y = 0; y < (85 * 9); y = y + 9) {
				BufferedImage tmp = new BufferedImage(tilesize, tilesize,
						BufferedImage.TYPE_INT_ARGB);
				Graphics gg = tmp.getGraphics();
				gg.drawImage(tileset, 0, 0, tilesize, tilesize, x, y, 9 + x,
						9 + y, null);
				array[y / 9][x / 9] = tmp;
			}
		}
		int indexX = field.getIndexX();
		int indexY = field.getIndexY();
		for (int m = 0; m < indexX; m++) {
			for (int n = 0; n < indexY; n++) {
				Tile tmp = field.getTile(m, n);
				g.drawImage(array[tmp.getImgNr()][tmp.getViewNr()], tmp
						.getXPos(), tmp.getYPos(), null);
			}
		}
	}
//*/
	
}




