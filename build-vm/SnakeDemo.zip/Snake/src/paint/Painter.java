/*
 * Painter.java
 *
 * Created on 10. Januar 2008, 20:54
 *
 * In dieser Klasse wird das Zeichnen organisiert.
 */

package paint;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;

import basics.Field;
import entitys.Bug;
import entitys.Centipede;
import entitys.Entity;
import entitys.Fly;
import entitys.Mouse;
import entitys.Slug;
import entitys.Snake;

public class Painter {
    protected int xPicture=0;
    protected int yPicture=0;
    private FieldPainter painter = null;
	EntityPainter ep = null;

    public Painter(int xPictureI,int yPictureI) {
        xPicture=xPictureI;
        yPicture=yPictureI;
        painter = new FieldPainter(xPicture,yPicture);
		ep = new EntityPainter();
        EntityPainter.xPicture = xPictureI;
        EntityPainter.yPicture = yPictureI;
    
    }
    

    public void newLevel(){
        FieldPainter.newLevel();
    }
    
    public Image paintFrame(Field field,Snake snake, Bug bug){
        if(bug!=null || snake !=null){
            return EntityPainter.paintBug(FieldPainter.paintField(field),snake,bug);
        }
        return FieldPainter.paintField(field);
    }
    
    
    
//     TODO update3 moreEntitys : comment the line below
    /*
	public Image paintFrame(Field field, Snake snake, Entity entity) {
		if (entity != null || snake != null) {
			return Painter.paintEntitys(FieldPainter.paintField(field), snake,
					entity);
		}
		return FieldPainter.paintField(field);
	}
    
	public static Image paintEntitys(Image background, Snake snake, Entity entity) {
		BufferedImage frame = new BufferedImage(EntityPainter.xPicture,
				EntityPainter.yPicture, BufferedImage.TYPE_INT_ARGB);
		try {
			Graphics g = frame.getGraphics();

			g.drawImage(background, 0, 0, null);

			if (!snake.alreadyMoved()) {
				EntityPainter.paintSnake(g, (Snake) snake);
			}
			if (entity != null) {
				if (entity.isA().equals("Bug")) {
					EntityPainter.paintBug(g, (Bug) entity);
				}
				if (entity.isA().equals("Fly")) {
					EntityPainter.paintFly(g, (Fly) entity);
				}
			}
			if (snake.alreadyMoved()) {
				EntityPainter.paintSnake(g, (Snake) snake);
			}
			if (entity != null) {
				if (entity.isA().equals("Fly")) {
					Fly fl = (Fly) entity;
					if (fl.isFlying()) {
						EntityPainter.paintFly(g, (Fly) entity);
					}
				}
			}
		} catch (Throwable e) {
			e.printStackTrace();
		}
		return frame;
	}
	//*/
	//End update3 more entities
    
}
